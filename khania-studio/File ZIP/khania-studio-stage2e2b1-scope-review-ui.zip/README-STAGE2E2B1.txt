KHANIA STUDIO — STAGE 2E-2B-1
Admin Scope Review — UI Prototype / Read-only

File:
admin-form-brief-scope.html

Upload:
 /public_html/admin-form-brief-scope.html

Buka:
https://khania-studio.com/admin-form-brief-scope.html

Target test:
Order KS-260922-85CA
Order UUID a689f24a-0f71-4be8-b430-c0615d88f926

Prasyarat:
- Login Admin aktif.
- Tidak perlu menjalankan SQL.
- Tidak ada data Scope Review yang disimpan pada tahap ini.

Fokus:
- Menampilkan Client Brief A-R secara berurutan.
- H Produk/Jasa tetap berada di antara G dan I.
- Section yang relevan memiliki 4 keputusan UI:
  INCLUDED = Termasuk Paket
  ADDITIONAL_COST = Tambahan Biaya
  NEED_CLARIFICATION = Perlu Informasi Klien
  NOT_INCLUDED = Tidak Diperlukan
- Catatan Admin bersifat UI-only pada tahap ini.
- Tombol workflow sengaja disabled.

Tabel brief_scope_reviews yang sudah ada tidak diubah pada tahap ini.
