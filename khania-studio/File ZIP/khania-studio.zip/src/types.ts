export interface PricingPackage {
  id: string;
  name: string;
  normalPrice: string;
  promoPrice: string;
  badge?: string;
  badgeColor?: string;
  isPopular?: boolean;
  targetAudience: string;
  deliveryTime: string;
  features: string[];
  note?: string;
  waMessage: string;
}

export interface PortfolioProject {
  id: string;
  category: string;
  badge: 'REAL BUSINESS PROJECT' | 'DEMO / CONCEPT PROJECT';
  badgeType: 'real' | 'demo';
  title: string;
  description: string;
  features: string[];
  url: string;
  ctaText: string;
  note?: string;
  imagePlaceholder: string;
  stats?: { label: string; value: string }[];
}

export interface ServiceItem {
  id: string;
  title: string;
  description: string;
  iconName: string;
  tag?: string;
}

export interface StepItem {
  number: string;
  title: string;
  description: string;
  iconName: string;
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category?: string;
}

export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  readTime: string;
  date: string;
  author: string;
  category: string;
  content: string[];
}
