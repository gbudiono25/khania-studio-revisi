import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ThreeBenefits } from './components/ThreeBenefits';
import { PortfolioSection } from './components/PortfolioSection';
import { DesignReferenceSection } from './components/DesignReferenceSection';
import { ServicesSection } from './components/ServicesSection';
import { OrderProcessSection } from './components/OrderProcessSection';
import { PricingSection } from './components/PricingSection';
import { FAQSection } from './components/FAQSection';
import { BlogSection } from './components/BlogSection';
import { FinalCTASection } from './components/FinalCTASection';
import { Footer } from './components/Footer';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { ReferenceConsultModal } from './components/ReferenceConsultModal';

export default function App() {
  const [isConsultModalOpen, setIsConsultModalOpen] = useState(false);

  return (
    <div className="min-h-screen bg-white text-slate-800 font-sans antialiased overflow-x-hidden selection:bg-indigo-500 selection:text-white">
      {/* Sticky Header Navigation */}
      <Navbar onOpenConsultation={() => setIsConsultModalOpen(true)} />

      {/* Main High-Converting Page Sections */}
      <main>
        {/* 1. Hero Section */}
        <Hero />

        {/* 2. Three Main Benefits (USP) */}
        <ThreeBenefits />

        {/* 3. Featured Portfolio Projects (Tanur Muthmainnah & Casa Loka) */}
        <PortfolioSection />

        {/* 4. Section Design Reference */}
        <DesignReferenceSection />

        {/* 5. Services / Layanan */}
        <ServicesSection />

        {/* 6. Order Process / Cara Pesan */}
        <OrderProcessSection />

        {/* 7. Pricing Packages & Delivery Time */}
        <PricingSection />

        {/* 8. FAQ Accordion */}
        <FAQSection />

        {/* 9. Blog Section (Max 3 Articles) */}
        <BlogSection />

        {/* 10. Final Conversion CTA */}
        <FinalCTASection />
      </main>

      {/* Footer */}
      <Footer />

      {/* Floating Elements & Modals */}
      <FloatingWhatsApp />
      <ReferenceConsultModal
        isOpen={isConsultModalOpen}
        onClose={() => setIsConsultModalOpen(false)}
      />
    </div>
  );
}
