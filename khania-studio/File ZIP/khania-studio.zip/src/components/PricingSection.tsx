import React from 'react';
import { Check, MessageSquare, Clock, ShieldCheck, Sparkles, AlertCircle } from 'lucide-react';
import { PRICING_PACKAGES, PRICING_DISCLAIMER, DELIVERY_ESTIMATES, DELIVERY_NOTE } from '../data/contentData';
import { getWhatsAppUrl } from '../utils/whatsapp';

export const PricingSection: React.FC = () => {
  return (
    <section id="harga" className="py-20 lg:py-28 bg-slate-50 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-100 border border-emerald-200 text-emerald-800 text-xs font-bold uppercase tracking-wider">
            TRANSPARAN & INVESTASI TERJANGKAU
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Pilih Paket Sesuai Kebutuhan Bisnis Anda
          </h2>
          <p className="text-slate-600 text-base sm:text-lg">
            Mulai dari landing page sederhana hingga website bisnis yang lebih lengkap.
          </p>
        </div>

        {/* 4 Pricing Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8 items-stretch mb-12">
          {PRICING_PACKAGES.map((pkg) => (
            <div
              key={pkg.id}
              className={`rounded-3xl p-6 sm:p-7 flex flex-col justify-between transition-all duration-300 relative ${
                pkg.isPopular
                  ? 'bg-slate-900 text-white border-2 border-indigo-500 shadow-2xl shadow-indigo-950/40 lg:-translate-y-2'
                  : 'bg-white text-slate-900 border border-slate-200/90 shadow-sm hover:shadow-md hover:border-slate-300'
              }`}
            >
              {/* Popular Badge */}
              {pkg.isPopular && (
                <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-indigo-600 text-white text-[11px] font-extrabold uppercase tracking-wider px-3.5 py-1 rounded-full shadow-md flex items-center gap-1">
                  <Sparkles className="w-3 h-3" />
                  <span>{pkg.badge}</span>
                </div>
              )}

              <div className="space-y-6">
                
                {/* Header */}
                <div className="space-y-2">
                  {!pkg.isPopular && pkg.badge && (
                    <span className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase border ${pkg.badgeColor}`}>
                      {pkg.badge}
                    </span>
                  )}
                  <h3 className={`text-xl font-extrabold tracking-tight ${pkg.isPopular ? 'text-white' : 'text-slate-900'}`}>
                    {pkg.name}
                  </h3>
                  <p className={`text-xs leading-relaxed ${pkg.isPopular ? 'text-slate-300' : 'text-slate-600'}`}>
                    {pkg.targetAudience}
                  </p>
                </div>

                {/* Price Display */}
                <div className="pt-2 pb-3 border-y border-slate-100 dark:border-slate-800 space-y-1">
                  <div className="flex items-baseline gap-2">
                    <span className={`text-xs line-through ${pkg.isPopular ? 'text-slate-400' : 'text-slate-400'}`}>
                      {pkg.normalPrice}
                    </span>
                    <span className="text-xs font-bold text-emerald-500 uppercase tracking-wider">
                      Harga Promo
                    </span>
                  </div>
                  <div className={`text-2xl sm:text-3xl font-black ${pkg.isPopular ? 'text-emerald-400' : 'text-emerald-600'}`}>
                    {pkg.promoPrice}
                  </div>
                  <div className={`text-[11px] flex items-center gap-1 ${pkg.isPopular ? 'text-slate-400' : 'text-slate-500'}`}>
                    <Clock className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
                    <span>Estimasi: {pkg.deliveryTime}</span>
                  </div>
                </div>

                {/* Feature List */}
                <div className="space-y-2.5">
                  <div className={`text-xs font-bold uppercase tracking-wider ${pkg.isPopular ? 'text-slate-400' : 'text-slate-500'}`}>
                    Sudah Termasuk:
                  </div>
                  <ul className="space-y-2 text-xs">
                    {pkg.features.map((feat, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <Check className={`w-4 h-4 shrink-0 mt-0.5 ${pkg.isPopular ? 'text-emerald-400' : 'text-emerald-600'}`} />
                        <span className={pkg.isPopular ? 'text-slate-200' : 'text-slate-700'}>
                          {feat}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>

                {pkg.note && (
                  <div className={`p-3 rounded-xl text-[11px] leading-relaxed ${
                    pkg.isPopular ? 'bg-indigo-950/80 border border-indigo-800 text-indigo-200' : 'bg-slate-100 text-slate-600'
                  }`}>
                    {pkg.note}
                  </div>
                )}

              </div>

              {/* CTA Button */}
              <div className="pt-6 mt-6 border-t border-slate-100 dark:border-slate-800">
                <a
                  href={getWhatsAppUrl(pkg.waMessage)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`w-full inline-flex items-center justify-center gap-2 font-extrabold py-3 px-4 rounded-xl text-xs transition-all duration-200 shadow-sm ${
                    pkg.isPopular
                      ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-emerald-500/20'
                      : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-indigo-600/10'
                  }`}
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>Pilih {pkg.name}</span>
                </a>
              </div>

            </div>
          ))}
        </div>

        {/* Price Disclaimer Notice */}
        <div className="max-w-3xl mx-auto bg-amber-50 border border-amber-200 rounded-2xl p-4 sm:p-5 flex items-start gap-3 text-amber-900 text-xs sm:text-sm mb-16">
          <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold">Ketentuan Harga: </span>
            <span>{PRICING_DISCLAIMER}</span>
          </div>
        </div>

        {/* Delivery Time Estimation Table / Card Section */}
        <div className="bg-white rounded-3xl p-8 border border-slate-200/90 shadow-sm max-w-4xl mx-auto space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
            <div>
              <h3 className="text-xl font-bold text-slate-900">
                Estimasi Waktu Pengerjaan Sesuai Paket
              </h3>
              <p className="text-xs text-slate-500">
                Workflow modern mempercepat proses desain tanpa mengorbankan kualitas.
              </p>
            </div>
            <div className="px-3 py-1 bg-indigo-50 border border-indigo-100 text-indigo-700 rounded-lg text-xs font-bold">
              Proses Cepat & Terukur
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
            {DELIVERY_ESTIMATES.map((item, idx) => (
              <div key={idx} className="p-4 rounded-2xl bg-slate-50 border border-slate-200/60">
                <div className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Paket {item.package}
                </div>
                <div className="text-base sm:text-lg font-black text-indigo-600 mt-1">
                  {item.time}
                </div>
              </div>
            ))}
          </div>

          <p className="text-xs text-slate-500 italic text-center pt-2">
            {DELIVERY_NOTE}
          </p>
        </div>

      </div>
    </section>
  );
};
