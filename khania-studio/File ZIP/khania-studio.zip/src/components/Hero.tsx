import React, { useState } from 'react';
import { MessageSquare, ArrowRight, ShieldCheck, CheckCircle2, Sparkles, Laptop, Smartphone, ExternalLink } from 'lucide-react';
import { HERO_CONTENT, PORTFOLIO_PROJECTS } from '../data/contentData';
import { getWhatsAppUrl } from '../utils/whatsapp';

export const Hero: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'tanur' | 'casaloka'>('tanur');

  const activeProject =
    activeTab === 'tanur' ? PORTFOLIO_PROJECTS[0] : PORTFOLIO_PROJECTS[1];

  const handleScrollToPortfolio = (e: React.MouseEvent) => {
    e.preventDefault();
    const portfolioSection = document.getElementById('portfolio');
    if (portfolioSection) {
      portfolioSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="beranda" className="relative pt-28 sm:pt-36 pb-16 lg:pb-24 overflow-hidden bg-slate-900 text-white">
      {/* Subtle Grid Background Pattern */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:3rem_3rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] opacity-40"></div>
      
      {/* Decorative Glow Elements */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-indigo-600/20 rounded-full blur-[120px] pointer-events-none"></div>
      <div className="absolute top-1/3 right-10 w-[300px] h-[300px] bg-emerald-600/10 rounded-full blur-[100px] pointer-events-none"></div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Conversion Copywriting */}
          <div className="lg:col-span-7 flex flex-col items-start space-y-6 text-left">
            
            {/* Top Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs sm:text-sm font-semibold tracking-wide">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              <span>{HERO_CONTENT.badge}</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-[2.75rem] font-extrabold tracking-tight text-white leading-[1.15]">
              Website Profesional.{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-300 via-indigo-200 to-emerald-300">
                Cepat Dibuat, Desain Sesuai Keinginan,
              </span>{' '}
              Harga Terjangkau.
            </h1>

            {/* Subheadline */}
            <p className="text-slate-300 text-base sm:text-lg leading-relaxed max-w-2xl">
              {HERO_CONTENT.subheadline}
            </p>

            {/* Promotional Price Highlight */}
            <div className="w-full sm:w-auto p-4 rounded-2xl bg-gradient-to-r from-indigo-950/80 to-slate-900/90 border border-indigo-500/30 backdrop-blur-sm shadow-lg">
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 sm:gap-4">
                <div className="px-3 py-1 bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 rounded-lg text-xs font-bold uppercase tracking-wider">
                  Harga Perkenalan
                </div>
                <div className="flex items-baseline gap-2">
                  <span className="text-slate-400 text-xs sm:text-sm line-through">Rp450.000</span>
                  <span className="text-xl sm:text-2xl font-black text-emerald-400">
                    {HERO_CONTENT.promoPrice}
                  </span>
                </div>
              </div>
              <p className="text-slate-400 text-xs mt-2 font-medium">
                {HERO_CONTENT.promoNotice}
              </p>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3.5 w-full pt-2">
              <a
                href={getWhatsAppUrl(
                  'Halo Khania Studio, saya tertarik konsultasi untuk pembuatan website bisnis saya.'
                )}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2.5 bg-emerald-500 hover:bg-emerald-600 text-slate-950 text-base font-bold px-6 py-3.5 rounded-xl shadow-lg shadow-emerald-500/25 hover:shadow-emerald-500/40 hover:-translate-y-0.5 transition-all duration-200"
              >
                <MessageSquare className="w-5 h-5 fill-slate-950" />
                <span>{HERO_CONTENT.primaryCta}</span>
              </a>

              <a
                href="#portfolio"
                onClick={handleScrollToPortfolio}
                className="inline-flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-base font-semibold px-6 py-3.5 rounded-xl border border-slate-700 hover:border-slate-600 transition-all duration-200"
              >
                <span>{HERO_CONTENT.secondaryCta}</span>
                <ArrowRight className="w-4 h-4" />
              </a>
            </div>

            {/* Trust Microcopy */}
            <div className="pt-2 flex flex-wrap items-center gap-y-2 gap-x-4 text-xs sm:text-sm text-slate-400 font-medium">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Konsultasi Gratis</span>
              </div>
              <div className="hidden sm:inline text-slate-600">•</div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Harga Transparan</span>
              </div>
              <div className="hidden sm:inline text-slate-600">•</div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Desain Fleksibel</span>
              </div>
              <div className="hidden sm:inline text-slate-600">•</div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Mobile Responsive</span>
              </div>
            </div>

          </div>

          {/* Right Column: Premium Interactive Mockup Visual */}
          <div className="lg:col-span-5 relative">
            
            {/* Visual Frame Container */}
            <div className="relative rounded-2xl bg-gradient-to-b from-slate-800/90 to-slate-900/90 border border-slate-700/80 p-3 sm:p-4 shadow-2xl shadow-indigo-950/50">
              
              {/* Window Bar Header */}
              <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800">
                <div className="flex items-center gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-rose-500/80"></div>
                  <div className="w-3 h-3 rounded-full bg-amber-500/80"></div>
                  <div className="w-3 h-3 rounded-full bg-emerald-500/80"></div>
                </div>
                
                {/* Project Toggle Tabs */}
                <div className="flex items-center bg-slate-950/80 p-1 rounded-lg border border-slate-800 text-xs">
                  <button
                    onClick={() => setActiveTab('tanur')}
                    className={`px-3 py-1 rounded-md font-semibold transition-all ${
                      activeTab === 'tanur'
                        ? 'bg-indigo-600 text-white shadow-sm'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Travel Umroh
                  </button>
                  <button
                    onClick={() => setActiveTab('casaloka')}
                    className={`px-3 py-1 rounded-md font-semibold transition-all ${
                      activeTab === 'casaloka'
                        ? 'bg-indigo-600 text-white shadow-sm'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Property
                  </button>
                </div>

                <div className="text-[11px] text-slate-500 font-mono hidden sm:block">
                  khania.studio
                </div>
              </div>

              {/* Project Preview Banner */}
              <div className="relative rounded-xl overflow-hidden bg-slate-950 border border-slate-800 aspect-[16/10] group">
                {activeTab === 'tanur' ? (
                  <div className="w-full h-full bg-gradient-to-br from-indigo-950 via-slate-900 to-emerald-950 p-5 flex flex-col justify-between text-left">
                    <div className="flex items-center justify-between">
                      <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold tracking-wider uppercase">
                        REAL BUSINESS PROJECT
                      </span>
                      <span className="text-xs text-slate-400 font-medium">Tanur Jatiasih</span>
                    </div>

                    <div className="space-y-2 my-auto">
                      <div className="text-xs text-indigo-300 font-semibold uppercase tracking-wider">
                        Travel Umroh & Haji
                      </div>
                      <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                        Tanur Muthmainnah Tour
                      </h3>
                      <p className="text-xs text-slate-300 line-clamp-2">
                        Website layanan perjalanan Umroh & Haji yang menampilkan paket, legalitas, serta konsultasi cepat via WhatsApp.
                      </p>
                    </div>

                    <div className="pt-2 flex items-center justify-between border-t border-slate-800/80">
                      <div className="flex gap-1.5">
                        <span className="px-2 py-0.5 rounded bg-slate-800 text-[10px] text-slate-300">
                          Live Business
                        </span>
                        <span className="px-2 py-0.5 rounded bg-slate-800 text-[10px] text-slate-300">
                          WA Integrated
                        </span>
                      </div>
                      <a
                        href={activeProject.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 text-xs text-indigo-400 font-bold hover:text-indigo-300"
                      >
                        <span>Buka Website</span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    </div>
                  </div>
                ) : (
                  <div className="w-full h-full bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950 p-5 flex flex-col justify-between text-left">
                    <div className="flex items-center justify-between">
                      <span className="px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold tracking-wider uppercase">
                        DEMO / CONCEPT PROJECT
                      </span>
                      <span className="text-xs text-slate-400 font-medium">Casa Loka</span>
                    </div>

                    <div className="space-y-2 my-auto">
                      <div className="text-xs text-amber-300 font-semibold uppercase tracking-wider">
                        Property / Real Estate
                      </div>
                      <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                        Casa Loka Residence
                      </h3>
                      <p className="text-xs text-slate-300 line-clamp-2">
                        Demo website pemasaran hunian modern dengan showcase unit, fasilitas, price list, & sales inquiry.
                      </p>
                    </div>

                    <div className="pt-2 flex items-center justify-between border-t border-slate-800/80">
                      <div className="flex gap-1.5">
                        <span className="px-2 py-0.5 rounded bg-slate-800 text-[10px] text-slate-300">
                          Concept Demo
                        </span>
                        <span className="px-2 py-0.5 rounded bg-slate-800 text-[10px] text-slate-300">
                          Property Showcase
                        </span>
                      </div>
                      <a
                        href={activeProject.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 text-xs text-amber-400 font-bold hover:text-amber-300"
                      >
                        <span>Buka Live Demo</span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    </div>
                  </div>
                )}
              </div>

              {/* Floating Feature Pills */}
              <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
                <div className="p-2.5 rounded-lg bg-slate-800/60 border border-slate-700/60 flex items-center gap-2">
                  <Laptop className="w-4 h-4 text-indigo-400 shrink-0" />
                  <span className="text-slate-300 text-[11px] font-medium">Tampilan Desktop Clean</span>
                </div>
                <div className="p-2.5 rounded-lg bg-slate-800/60 border border-slate-700/60 flex items-center gap-2">
                  <Smartphone className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span className="text-slate-300 text-[11px] font-medium">Optimasi Layar HP</span>
                </div>
              </div>

            </div>

            {/* Small Decorative Badge */}
            <div className="absolute -bottom-4 -left-2 sm:-left-4 bg-emerald-950/90 border border-emerald-500/40 text-emerald-200 px-3 py-1.5 rounded-xl text-xs font-semibold shadow-lg flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span>Siap Kerjakan Website Anda</span>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
