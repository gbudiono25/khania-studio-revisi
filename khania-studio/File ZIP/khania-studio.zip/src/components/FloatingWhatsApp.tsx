import React, { useState } from 'react';
import { MessageSquare, X } from 'lucide-react';
import { KHANIA_INFO } from '../data/contentData';
import { getWhatsAppUrl } from '../utils/whatsapp';

export const FloatingWhatsApp: React.FC = () => {
  const [showTooltip, setShowTooltip] = useState(true);

  return (
    <div className="fixed bottom-5 right-5 z-40 flex flex-col items-end gap-2 group">
      {/* Tooltip Badge */}
      {showTooltip && (
        <div className="bg-slate-900 text-white border border-slate-700 text-xs px-3 py-1.5 rounded-xl shadow-xl flex items-center gap-2 animate-bounce">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span>Konsultasi WA Gratis!</span>
          <button
            onClick={() => setShowTooltip(false)}
            className="text-slate-400 hover:text-white p-0.5 ml-1"
            aria-label="Close tooltip"
          >
            <X className="w-3 h-3" />
          </button>
        </div>
      )}

      {/* Floating Action Button */}
      <a
        href={getWhatsAppUrl(
          'Halo Khania Studio, saya melihat website Khania Studio dan ingin konsultasi pembuatan website.'
        )}
        target="_blank"
        rel="noopener noreferrer"
        className="w-14 h-14 bg-emerald-500 hover:bg-emerald-600 text-slate-950 rounded-full flex items-center justify-center shadow-xl shadow-emerald-500/30 hover:scale-110 active:scale-95 transition-all duration-200 border-2 border-white/20"
        aria-label="Hubungi via WhatsApp"
      >
        <MessageSquare className="w-7 h-7 fill-slate-950" />
      </a>
    </div>
  );
};
