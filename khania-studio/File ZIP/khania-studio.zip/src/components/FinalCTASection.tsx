import React from 'react';
import { MessageSquare, ArrowRight, ShieldCheck, Sparkles, CheckCircle2 } from 'lucide-react';
import { FINAL_CTA_CONTENT } from '../data/contentData';
import { getWhatsAppUrl } from '../utils/whatsapp';

export const FinalCTASection: React.FC = () => {
  const handleScrollToPortfolio = (e: React.MouseEvent) => {
    e.preventDefault();
    const portfolioSection = document.getElementById('portfolio');
    if (portfolioSection) {
      portfolioSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="py-20 lg:py-28 bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-900 text-white relative overflow-hidden">
      {/* Background Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-emerald-600/10 rounded-full blur-[140px] pointer-events-none"></div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative text-center space-y-8">
        
        {/* Highlight Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-xs sm:text-sm font-extrabold uppercase tracking-wider">
          <Sparkles className="w-4 h-4 text-emerald-400" />
          <span>{FINAL_CTA_CONTENT.highlight}</span>
        </div>

        {/* Heading */}
        <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-white leading-tight">
          {FINAL_CTA_CONTENT.heading}
        </h2>

        {/* Text */}
        <p className="text-slate-300 text-base sm:text-lg max-w-3xl mx-auto leading-relaxed">
          {FINAL_CTA_CONTENT.text}
        </p>

        {/* Action Buttons */}
        <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4 max-w-md mx-auto">
          <a
            href={getWhatsAppUrl(
              'Halo Khania Studio, saya siap konsultasi untuk pembuatan website bisnis saya.'
            )}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold text-base px-8 py-4 rounded-2xl shadow-xl shadow-emerald-500/25 hover:shadow-emerald-500/40 hover:-translate-y-0.5 transition-all duration-200"
          >
            <MessageSquare className="w-5 h-5 fill-slate-950" />
            <span>{FINAL_CTA_CONTENT.primaryCta}</span>
          </a>

          <a
            href="#portfolio"
            onClick={handleScrollToPortfolio}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-base px-6 py-4 rounded-2xl border border-slate-700 transition-colors"
          >
            <span>{FINAL_CTA_CONTENT.secondaryCta}</span>
            <ArrowRight className="w-4 h-4" />
          </a>
        </div>

        {/* Microcopy Trust */}
        <div className="pt-4 text-xs sm:text-sm text-slate-400 font-medium flex items-center justify-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{FINAL_CTA_CONTENT.microcopy}</span>
        </div>

      </div>
    </section>
  );
};
