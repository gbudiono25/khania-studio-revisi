import React from 'react';
import { X, Clock, Calendar, User, MessageSquare } from 'lucide-react';
import { BlogPost } from '../types';
import { getWhatsAppUrl } from '../utils/whatsapp';

interface ArticleModalProps {
  post: BlogPost | null;
  onClose: () => void;
}

export const ArticleModal: React.FC<ArticleModalProps> = ({ post, onClose }) => {
  if (!post) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto border border-slate-200 shadow-2xl relative flex flex-col justify-between">
        
        {/* Header Bar */}
        <div className="sticky top-0 bg-white/95 backdrop-blur-md border-b border-slate-100 p-6 flex items-center justify-between z-10">
          <span className="px-3 py-1 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200 text-xs font-bold uppercase tracking-wider">
            {post.category}
          </span>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-8 space-y-6">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            {post.title}
          </h2>

          <div className="flex flex-wrap items-center gap-4 text-xs text-slate-500 font-medium border-b border-slate-100 pb-4">
            <div className="flex items-center gap-1.5">
              <Calendar className="w-4 h-4 text-indigo-500" />
              <span>{post.date}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-indigo-500" />
              <span>{post.readTime}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <User className="w-4 h-4 text-indigo-500" />
              <span>{post.author}</span>
            </div>
          </div>

          <div className="space-y-4 text-slate-700 text-sm sm:text-base leading-relaxed">
            {post.content.map((paragraph, idx) => (
              <p key={idx}>{paragraph}</p>
            ))}
          </div>
        </div>

        {/* Modal Footer CTA */}
        <div className="p-6 bg-slate-50 border-t border-slate-100 rounded-b-3xl flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-xs text-slate-600 font-medium">
            Ingin berkonsultasi mengenai penerapan website untuk bisnis Anda?
          </div>
          <a
            href={getWhatsAppUrl(
              `Halo Khania Studio, saya membaca artikel "${post.title}" dan tertarik berkonsultasi.`
            )}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-5 py-2.5 rounded-xl transition-all shadow-sm shrink-0"
          >
            <MessageSquare className="w-4 h-4" />
            <span>Konsultasi WA</span>
          </a>
        </div>

      </div>
    </div>
  );
};
