import React from 'react';
import { MessageSquare, Palette, FolderUp, CheckCircle2, ArrowRight } from 'lucide-react';
import { ORDER_STEPS } from '../data/contentData';
import { getWhatsAppUrl } from '../utils/whatsapp';

export const OrderProcessSection: React.FC = () => {
  const getStepIcon = (iconName: string) => {
    switch (iconName) {
      case 'MessageSquare':
        return <MessageSquare className="w-6 h-6 text-indigo-600" />;
      case 'Palette':
        return <Palette className="w-6 h-6 text-indigo-600" />;
      case 'FolderUp':
        return <FolderUp className="w-6 h-6 text-indigo-600" />;
      default:
        return <CheckCircle2 className="w-6 h-6 text-emerald-600" />;
    }
  };

  return (
    <section id="cara-pesan" className="py-20 lg:py-28 bg-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs font-bold uppercase tracking-wider">
            ALUR KERJA RAPI & SIP
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Website Anda Bisa Dimulai dalam 4 Langkah
          </h2>
          <p className="text-slate-600 text-base sm:text-lg">
            Proses pemesanan simpel tanpa birokrasi rumit.
          </p>
        </div>

        {/* 4 Order Steps Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8 mb-12">
          {ORDER_STEPS.map((step) => (
            <div
              key={step.number}
              className="bg-slate-50 rounded-2xl p-6 sm:p-7 border border-slate-200/80 hover:border-indigo-300 transition-all duration-200 flex flex-col justify-between relative group"
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-black text-indigo-600">
                    {step.number}
                  </span>
                  <div className="w-10 h-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center shadow-sm">
                    {getStepIcon(step.iconName)}
                  </div>
                </div>

                <h3 className="text-lg font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                  {step.title}
                </h3>

                <p className="text-slate-600 text-xs sm:text-sm leading-relaxed">
                  {step.description}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* CTA & Microcopy Box */}
        <div className="bg-gradient-to-r from-indigo-900 to-slate-900 text-white rounded-3xl p-8 sm:p-10 shadow-xl text-center max-w-4xl mx-auto space-y-6">
          <h3 className="text-2xl sm:text-3xl font-extrabold text-white">
            Bingung Memilih Paket yang Tepat?
          </h3>
          <p className="text-slate-300 text-sm sm:text-base max-w-2xl mx-auto leading-relaxed">
            Belum tahu paket yang cocok? Ceritakan kebutuhan Anda terlebih dahulu. Kami bantu memilihkan tanpa kewajiban membeli.
          </p>
          <div className="pt-2">
            <a
              href={getWhatsAppUrl(
                'Halo Khania Studio, saya ingin konsultasi awal mengenai kebutuhan website untuk bisnis saya.'
              )}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2.5 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-extrabold px-8 py-4 rounded-xl shadow-lg shadow-emerald-500/20 text-base transition-all"
            >
              <MessageSquare className="w-5 h-5 fill-slate-950" />
              <span>Mulai Konsultasi Gratis</span>
            </a>
          </div>
          <p className="text-xs text-slate-400">
            Konsultasi Gratis • Tanpa Risiko • Transparan
          </p>
        </div>

      </div>
    </section>
  );
};
