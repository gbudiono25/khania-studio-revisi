import React, { useState } from 'react';
import { X, Send, Link2, MessageSquare, Sparkles } from 'lucide-react';
import { PRICING_PACKAGES } from '../data/contentData';
import { getWhatsAppUrl } from '../utils/whatsapp';

interface ReferenceConsultModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ReferenceConsultModal: React.FC<ReferenceConsultModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [url, setUrl] = useState('');
  const [businessName, setBusinessName] = useState('');
  const [selectedPkg, setSelectedPkg] = useState('starter');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const pkgName =
      PRICING_PACKAGES.find((p) => p.id === selectedPkg)?.name || 'Starter';
    
    let text = `Halo Khania Studio, saya ingin konsultasi website.`;
    if (businessName) {
      text += `\n- Nama Bisnis: ${businessName}`;
    }
    if (url) {
      text += `\n- Contoh Referensi Website: ${url}`;
    }
    text += `\n- Tertarik Paket: ${pkgName}`;

    window.open(getWhatsAppUrl(text), '_blank');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 border border-slate-200 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-full transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="space-y-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-bold uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Konsultasi Referensi</span>
            </div>
            <h3 className="text-2xl font-extrabold text-slate-900 tracking-tight">
              Kirimkan Contoh Website Impian Anda
            </h3>
            <p className="text-slate-600 text-xs sm:text-sm">
              Tempelkan link atau deskripsi gaya website yang Anda sukai. Kami bantu sesuaikan dengan bisnis Anda.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-bold uppercase text-slate-700 mb-1.5">
                Nama / Jenis Bisnis Anda
              </label>
              <input
                type="text"
                value={businessName}
                onChange={(e) => setBusinessName(e.target.value)}
                placeholder="Contoh: Toko Baju Online / Travel / Properti"
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-sm focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase text-slate-700 mb-1.5">
                Link / Referensi Website yang Disukai
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <Link2 className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  placeholder="https://contoh-website.com"
                  className="w-full pl-9 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-sm focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase text-slate-700 mb-1.5">
                Pilih Paket
              </label>
              <select
                value={selectedPkg}
                onChange={(e) => setSelectedPkg(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-sm focus:outline-none focus:border-indigo-500"
              >
                <option value="starter">Paket Starter (Rp399.000)</option>
                <option value="bronze">Paket Bronze (Rp699.000)</option>
                <option value="silver">Paket Silver (Rp1.390.000 - Rekomendasi)</option>
                <option value="gold">Paket Gold (Rp2.090.000)</option>
              </select>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="w-full inline-flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold py-3.5 px-6 rounded-xl shadow-lg shadow-emerald-600/20 text-sm transition-all"
              >
                <MessageSquare className="w-4 h-4 fill-white" />
                <span>Kirim ke WhatsApp Sekarang</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
