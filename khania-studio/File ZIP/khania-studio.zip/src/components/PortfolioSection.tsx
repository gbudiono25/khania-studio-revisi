import React from 'react';
import { ExternalLink, CheckCircle2, ShieldCheck, ArrowUpRight, Building2, Plane } from 'lucide-react';
import { PORTFOLIO_PROJECTS } from '../data/contentData';

export const PortfolioSection: React.FC = () => {
  return (
    <section id="portfolio" className="py-20 lg:py-28 bg-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs font-bold uppercase tracking-wider">
            BUKTI KUALITAS DESAIN
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Lihat Kualitasnya Sebelum Memutuskan
          </h2>
          <p className="text-slate-600 text-base sm:text-lg">
            Tidak perlu hanya percaya pada janji. Buka langsung beberapa website yang sudah kami buat dan lihat desain, struktur, serta pengalaman penggunaannya.
          </p>
        </div>

        {/* 2 Featured Projects Cards Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-10">
          
          {PORTFOLIO_PROJECTS.map((project) => (
            <div
              key={project.id}
              className="bg-slate-900 text-white rounded-3xl overflow-hidden border border-slate-800 shadow-xl flex flex-col justify-between hover:border-slate-700 transition-all duration-300 group"
            >
              {/* Card Visual Header Banner */}
              <div className="relative p-6 sm:p-8 bg-gradient-to-br from-slate-900 via-slate-950 to-indigo-950 border-b border-slate-800/80">
                
                {/* Badge Top Bar */}
                <div className="flex flex-wrap items-center justify-between gap-2 mb-6">
                  <span className="text-xs font-bold text-indigo-300 tracking-wider uppercase">
                    {project.category}
                  </span>
                  
                  {project.badgeType === 'real' ? (
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bold uppercase tracking-wider">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      {project.badge}
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-bold uppercase tracking-wider">
                      {project.badge}
                    </span>
                  )}
                </div>

                {/* Project Title */}
                <h3 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight mb-3 group-hover:text-indigo-300 transition-colors">
                  {project.title}
                </h3>

                {/* Project Description */}
                <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
                  {project.description}
                </p>

                {/* Project Mockup Container Preview */}
                <div className="mt-6 p-4 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
                      {project.id === 'tanur-jatiasih' ? (
                        <Plane className="w-5 h-5" />
                      ) : (
                        <Building2 className="w-5 h-5" />
                      )}
                    </div>
                    <div>
                      <div className="text-xs text-slate-400 font-mono">
                        {project.url.replace('https://', '').replace('/', '')}
                      </div>
                      <div className="text-xs font-semibold text-emerald-400 flex items-center gap-1">
                        <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                        <span>Live Preview Ready</span>
                      </div>
                    </div>
                  </div>

                  <a
                    href={project.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hidden sm:inline-flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold px-3.5 py-2 rounded-xl transition-colors shadow-sm"
                  >
                    <span>Uji Coba</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>

              {/* Card Features List & Action Footer */}
              <div className="p-6 sm:p-8 bg-slate-900 flex flex-col justify-between flex-grow space-y-6">
                
                <div className="space-y-3">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                    Fitur & Keunggulan Website:
                  </h4>
                  <div className="grid grid-cols-2 gap-2.5">
                    {project.features.map((feature, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-xs text-slate-300">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span>{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {project.note && (
                  <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-200/90 leading-relaxed">
                    {project.note}
                  </div>
                )}

                {/* Main CTA Button */}
                <div className="pt-2">
                  <a
                    href={project.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full inline-flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold py-3.5 px-6 rounded-xl shadow-lg shadow-indigo-600/25 transition-all text-sm group-hover:scale-[1.01]"
                  >
                    <span>{project.ctaText}</span>
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>

              </div>

            </div>
          ))}

        </div>

        {/* Small Bottom Guarantee Banner */}
        <div className="mt-12 text-center max-w-2xl mx-auto p-4 rounded-2xl bg-indigo-50 border border-indigo-100 text-slate-700 text-xs sm:text-sm">
          💡 <span className="font-semibold text-slate-900">Ingin website dengan standar kualitas yang sama?</span> Hubungi kami dan kirimkan contoh referensi yang Anda inginkan.
        </div>

      </div>
    </section>
  );
};
