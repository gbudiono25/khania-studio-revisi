import React from 'react';
import { Clock, Palette, DollarSign, ArrowRight, CheckCircle2, Sparkles } from 'lucide-react';
import { THREE_BENEFITS } from '../data/contentData';
import { getWhatsAppUrl } from '../utils/whatsapp';

export const ThreeBenefits: React.FC = () => {
  return (
    <section id="keunggulan" className="py-20 lg:py-28 bg-slate-50 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-100 border border-indigo-200 text-indigo-700 text-xs font-bold uppercase tracking-wider">
            KEUNGGULAN UTAMA KHANIA STUDIO
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            {THREE_BENEFITS.heading}
          </h2>
          <p className="text-slate-600 text-base sm:text-lg">
            {THREE_BENEFITS.subheading}
          </p>
        </div>

        {/* 3 Prominent Benefit Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch">
          
          {/* Benefit 1: Pengerjaan Cepat */}
          <div className="bg-white rounded-2xl p-8 border border-slate-200/80 shadow-md shadow-slate-200/50 hover:shadow-xl hover:border-indigo-300 transition-all duration-300 flex flex-col justify-between group relative overflow-hidden">
            <div className="absolute top-0 left-0 w-2 h-full bg-indigo-600"></div>
            
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <span className="text-3xl font-black text-indigo-600/30 group-hover:text-indigo-600 transition-colors">
                  01
                </span>
                <div className="w-12 h-12 rounded-xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 group-hover:scale-110 transition-transform">
                  <Clock className="w-6 h-6" />
                </div>
              </div>

              <div className="space-y-3">
                <h3 className="text-xl font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                  Pengerjaan Cepat
                </h3>
                <p className="text-slate-600 text-sm leading-relaxed">
                  Tidak perlu menunggu berminggu-minggu untuk memiliki website. Kami menggunakan workflow modern untuk mempercepat proses desain dan pembuatan website tanpa mengabaikan kualitas.
                </p>
              </div>
            </div>

            <div className="pt-6 mt-6 border-t border-slate-100 space-y-2">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-indigo-50 rounded-lg text-indigo-700 text-xs font-semibold">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Mulai 1–24 Jam</span>
              </div>
              <p className="text-xs text-slate-500 italic">
                Estimasi pengerjaan menyesuaikan paket dan kompleksitas website.
              </p>
            </div>
          </div>

          {/* Benefit 2: Desain Sesuai Referensi Anda */}
          <div className="bg-gradient-to-b from-indigo-900 to-slate-900 text-white rounded-2xl p-8 border border-indigo-800 shadow-xl shadow-indigo-950/20 hover:shadow-2xl transition-all duration-300 flex flex-col justify-between relative overflow-hidden group">
            
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <span className="text-3xl font-black text-indigo-400/40">
                  02
                </span>
                <div className="w-12 h-12 rounded-xl bg-indigo-800/60 border border-indigo-700 flex items-center justify-center text-indigo-300">
                  <Palette className="w-6 h-6" />
                </div>
              </div>

              <div className="space-y-3">
                <h3 className="text-xl font-bold text-white">
                  Desain Sesuai Referensi Anda
                </h3>
                <p className="text-slate-300 text-sm leading-relaxed">
                  Punya website, template, atau layout yang Anda suka? Kirimkan link atau screenshot-nya. Kami akan menggunakannya sebagai inspirasi dan menyesuaikan desain dengan logo, warna, konten, dan karakter bisnis Anda.
                </p>
              </div>

              {/* Visual Step Diagram: Referensi -> Customisasi -> Website Anda */}
              <div className="p-3.5 rounded-xl bg-slate-950/80 border border-indigo-500/30 text-xs space-y-2">
                <div className="text-[11px] uppercase tracking-wider text-indigo-300 font-bold">
                  Alur Pembuatan Desain:
                </div>
                <div className="flex items-center justify-between text-slate-300 font-medium text-[11px] gap-1">
                  <span className="px-2 py-1 rounded bg-indigo-900/60 text-indigo-200">Referensi</span>
                  <ArrowRight className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                  <span className="px-2 py-1 rounded bg-indigo-900/60 text-indigo-200">Customisasi</span>
                  <ArrowRight className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                  <span className="px-2 py-1 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">Website Anda</span>
                </div>
              </div>
            </div>

            <div className="pt-6 mt-6 border-t border-indigo-800/80">
              <a
                href={getWhatsAppUrl(
                  'Halo Khania Studio, saya punya referensi contoh website yang saya sukai dan ingin konsultasi pembuatan website.'
                )}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full inline-flex items-center justify-center gap-2 bg-indigo-500 hover:bg-indigo-600 text-white font-semibold py-2.5 px-4 rounded-xl text-xs transition-colors"
              >
                <Sparkles className="w-4 h-4" />
                <span>Kirim Referensi Website Anda</span>
              </a>
            </div>

          </div>

          {/* Benefit 3: Harga Terjangkau & Transparan */}
          <div className="bg-white rounded-2xl p-8 border border-slate-200/80 shadow-md shadow-slate-200/50 hover:shadow-xl hover:border-emerald-300 transition-all duration-300 flex flex-col justify-between group relative overflow-hidden">
            <div className="absolute top-0 left-0 w-2 h-full bg-emerald-500"></div>

            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <span className="text-3xl font-black text-emerald-600/30 group-hover:text-emerald-600 transition-colors">
                  03
                </span>
                <div className="w-12 h-12 rounded-xl bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-600 group-hover:scale-110 transition-transform">
                  <DollarSign className="w-6 h-6" />
                </div>
              </div>

              <div className="space-y-3">
                <h3 className="text-xl font-bold text-slate-900 group-hover:text-emerald-600 transition-colors">
                  Harga Terjangkau & Transparan
                </h3>
                <p className="text-slate-600 text-sm leading-relaxed">
                  Pilih paket sesuai kebutuhan dan anggaran bisnis Anda. Harga dijelaskan sejak awal sehingga Anda mengetahui apa yang akan didapatkan tanpa biaya tak terduga.
                </p>
              </div>
            </div>

            <div className="pt-6 mt-6 border-t border-slate-100 space-y-2">
              <div className="inline-flex items-center gap-2">
                <span className="text-xs text-slate-500 font-medium">Harga Promo Perkenalan:</span>
                <span className="text-lg font-extrabold text-emerald-600">Mulai Rp399.000</span>
              </div>
              <p className="text-xs text-slate-500">
                Pilihan paket lengkap dari Starter hingga Gold.
              </p>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
