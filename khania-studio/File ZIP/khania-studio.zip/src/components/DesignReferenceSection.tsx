import React, { useState } from 'react';
import { Send, ArrowDown, ArrowRight, Sparkles, MessageSquare, Link2, Layout, CheckCircle2 } from 'lucide-react';
import { DESIGN_REFERENCE_SECTION } from '../data/contentData';
import { getWhatsAppUrl } from '../utils/whatsapp';

export const DesignReferenceSection: React.FC = () => {
  const [referenceUrl, setReferenceUrl] = useState('');

  const handleSendReference = (e: React.FormEvent) => {
    e.preventDefault();
    const msg = referenceUrl.trim()
      ? `Halo Khania Studio, saya punya contoh referensi website ini: "${referenceUrl.trim()}". Saya ingin konsultasi pembuatan website untuk bisnis saya.`
      : `Halo Khania Studio, saya mempunyai contoh referensi website yang saya sukai dan ingin konsultasi pembuatan website.`;
    window.open(getWhatsAppUrl(msg), '_blank');
  };

  return (
    <section className="py-20 lg:py-28 bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 text-white relative overflow-hidden">
      {/* Background Decorative Blur */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-[100px] pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-[100px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        
        <div className="max-w-3xl mx-auto text-center space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 text-xs font-bold uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            <span>KUSTOMISASI BEBAS SAMA SEKALI</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white">
            {DESIGN_REFERENCE_SECTION.heading}
          </h2>
          <p className="text-slate-300 text-base sm:text-lg leading-relaxed">
            {DESIGN_REFERENCE_SECTION.subheading}
          </p>
        </div>

        {/* 3 Step Visual Process Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16 items-center">
          
          {/* Step 1 */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 sm:p-8 text-center relative group hover:border-indigo-500/50 transition-colors">
            <div className="w-12 h-12 rounded-2xl bg-indigo-600/20 border border-indigo-500/30 text-indigo-400 flex items-center justify-center font-extrabold text-xl mx-auto mb-4">
              1
            </div>
            <h3 className="text-xl font-bold text-white mb-2">1. Kirim Referensi</h3>
            <p className="text-slate-300 text-sm leading-relaxed">
              Kirimkan link website, screenshot, template, atau layout yang Anda sukai.
            </p>
            <div className="mt-4 inline-block px-3 py-1 rounded bg-slate-800 text-slate-400 text-xs font-mono">
              Website, Screenshot, Template
            </div>

            {/* Desktop Connector Arrow */}
            <div className="hidden md:block absolute -right-4 top-1/2 -translate-y-1/2 z-10 text-indigo-400">
              <ArrowRight className="w-8 h-8" />
            </div>
            {/* Mobile Connector Arrow */}
            <div className="md:hidden flex justify-center mt-4 text-indigo-400">
              <ArrowDown className="w-6 h-6" />
            </div>
          </div>

          {/* Step 2 */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 sm:p-8 text-center relative group hover:border-indigo-500/50 transition-colors">
            <div className="w-12 h-12 rounded-2xl bg-indigo-600/20 border border-indigo-500/30 text-indigo-400 flex items-center justify-center font-extrabold text-xl mx-auto mb-4">
              2
            </div>
            <h3 className="text-xl font-bold text-white mb-2">2. Kami Sesuaikan</h3>
            <p className="text-slate-300 text-sm leading-relaxed">
              Kami menyesuaikan tata letak dengan warna, logo, konten, dan karakter unik bisnis Anda.
            </p>
            <div className="mt-4 inline-block px-3 py-1 rounded bg-slate-800 text-slate-400 text-xs font-mono">
              Logo, Warna, Konten Bisnis
            </div>

            {/* Desktop Connector Arrow */}
            <div className="hidden md:block absolute -right-4 top-1/2 -translate-y-1/2 z-10 text-indigo-400">
              <ArrowRight className="w-8 h-8" />
            </div>
            {/* Mobile Connector Arrow */}
            <div className="md:hidden flex justify-center mt-4 text-indigo-400">
              <ArrowDown className="w-6 h-6" />
            </div>
          </div>

          {/* Step 3 */}
          <div className="bg-gradient-to-br from-indigo-950 to-slate-900 border border-indigo-500/40 rounded-2xl p-6 sm:p-8 text-center relative group shadow-xl">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 flex items-center justify-center font-extrabold text-xl mx-auto mb-4">
              3
            </div>
            <h3 className="text-xl font-bold text-white mb-2">3. Website Anda Dibuat</h3>
            <p className="text-slate-300 text-sm leading-relaxed">
              Hasil akhirnya menjadi website profesional dengan identitas brand Anda sendiri.
            </p>
            <div className="mt-4 inline-block px-3 py-1 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bold">
              Siap Dipublikasikan Online
            </div>
          </div>

        </div>

        {/* Quick Reference Link Form Box */}
        <div className="max-w-2xl mx-auto bg-slate-950/80 border border-indigo-500/30 rounded-2xl p-6 sm:p-8 shadow-2xl backdrop-blur-md">
          <form onSubmit={handleSendReference} className="space-y-4">
            <label className="block text-sm font-semibold text-indigo-200">
              Punya link contoh website yang Anda sukai? Tempelkan di sini:
            </label>
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-grow">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                  <Link2 className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  value={referenceUrl}
                  onChange={(e) => setReferenceUrl(e.target.value)}
                  placeholder="Contoh: https://contoh-website.com atau deskripsi"
                  className="w-full pl-10 pr-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white placeholder-slate-500 text-sm focus:outline-none focus:border-indigo-500 transition-colors"
                />
              </div>
              <button
                type="submit"
                className="inline-flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold px-6 py-3 rounded-xl shadow-lg shadow-emerald-600/20 transition-all text-sm shrink-0"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Kirim via WA</span>
              </button>
            </div>
            <p className="text-xs text-slate-400 text-center pt-2">
              {DESIGN_REFERENCE_SECTION.microcopy}
            </p>
          </form>
        </div>

      </div>
    </section>
  );
};
