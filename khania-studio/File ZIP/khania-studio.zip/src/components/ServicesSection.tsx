import React from 'react';
import { Layout, Building, FileText, Building2, Plane, Sparkles, MessageSquare, ArrowRight } from 'lucide-react';
import { SERVICES_LIST } from '../data/contentData';
import { getWhatsAppUrl } from '../utils/whatsapp';

export const ServicesSection: React.FC = () => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Layout':
        return <Layout className="w-6 h-6 text-indigo-600" />;
      case 'Building':
        return <Building className="w-6 h-6 text-indigo-600" />;
      case 'FileText':
        return <FileText className="w-6 h-6 text-indigo-600" />;
      case 'Building2':
        return <Building2 className="w-6 h-6 text-indigo-600" />;
      case 'Plane':
        return <Plane className="w-6 h-6 text-indigo-600" />;
      default:
        return <Sparkles className="w-6 h-6 text-indigo-600" />;
    }
  };

  return (
    <section id="layanan" className="py-20 lg:py-28 bg-slate-50 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-100 border border-indigo-200 text-indigo-700 text-xs font-bold uppercase tracking-wider">
            KATEGORI LAYANAN
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Website Apa yang Bisa Kami Buat?
          </h2>
          <p className="text-slate-600 text-base sm:text-lg">
            Kami menyesuaikan jenis dan struktur website sesuai dengan tujuan spesifik bisnis Anda.
          </p>
        </div>

        {/* 6 Service Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {SERVICES_LIST.map((service) => (
            <div
              key={service.id}
              className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/90 shadow-sm hover:shadow-md hover:border-indigo-300 transition-all duration-200 flex flex-col justify-between group"
            >
              <div className="space-y-4">
                <div className="w-12 h-12 rounded-xl bg-indigo-50 border border-indigo-100 flex items-center justify-center group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                  {getIcon(service.iconName)}
                </div>
                <h3 className="text-xl font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                  {service.title}
                </h3>
                <p className="text-slate-600 text-sm leading-relaxed">
                  {service.description}
                </p>
              </div>

              <div className="pt-6 mt-6 border-t border-slate-100">
                <a
                  href={getWhatsAppUrl(
                    `Halo Khania Studio, saya berminat membuat ${service.title} untuk bisnis saya. Mohon info lebih lanjut.`
                  )}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-600 hover:text-indigo-800 transition-colors"
                >
                  <span>Konsultasikan Jenis Ini</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* Global CTA Banner for Services */}
        <div className="mt-12 text-center">
          <a
            href={getWhatsAppUrl(
              'Halo Khania Studio, saya ingin bertanya tentang pembuatan website yang sesuai dengan bisnis saya.'
            )}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold px-8 py-4 rounded-xl shadow-lg shadow-emerald-600/20 transition-all duration-200 text-base"
          >
            <MessageSquare className="w-5 h-5 fill-white" />
            <span>Tanyakan Website yang Saya Butuhkan</span>
          </a>
        </div>

      </div>
    </section>
  );
};
