import { KHANIA_INFO } from '../data/contentData';

/**
 * Generates a WhatsApp click-to-chat URL with pre-filled message
 * @param customMessage Custom message string or default message
 * @returns Encoded wa.me URL
 */
export function getWhatsAppUrl(customMessage?: string): string {
  const phone = KHANIA_INFO.whatsappNumber.replace(/[^0-9]/g, '');
  const defaultText =
    'Halo Khania Studio, saya melihat website Khania Studio dan tertarik membuat website untuk bisnis saya. Saya ingin konsultasi terlebih dahulu.';
  
  const text = customMessage || defaultText;
  return `https://wa.me/${phone}?text=${encodeURIComponent(text)}`;
}

/**
 * Format currency string for display
 */
export function formatRupiah(amount: number): string {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    maximumFractionDigits: 0,
  }).format(amount);
}
