import { PricingPackage, PortfolioProject, ServiceItem, StepItem, FAQItem, BlogPost } from '../types';

export const KHANIA_INFO = {
  name: 'Khania Studio',
  whatsappNumber: '6285179929280',
  whatsappDisplay: '0851-7992-9280',
  email: 'hello@khania.studio',
  location: 'Jawa Barat, Indonesia',
  workingHours: 'Senin - Sabtu: 08.00 - 20.00 WIB',
  instagram: '@khania.studio',
  tagline: 'Jasa Pembuatan Website Profesional & Terjangkau',
};

export const HERO_CONTENT = {
  badge: 'JASA PEMBUATAN WEBSITE PROFESIONAL',
  headline: 'Website Profesional. Cepat Dibuat, Desain Sesuai Keinginan, Harga Terjangkau.',
  subheadline:
    'Kami membantu UMKM dan pemilik bisnis memiliki website profesional tanpa proses yang rumit. Punya contoh website yang Anda suka? Kirimkan kepada kami dan kami akan menjadikannya referensi untuk membuat desain yang sesuai dengan bisnis Anda.',
  promoPrice: 'Website Mulai Rp399.000',
  promoNotice: 'Program Harga Perkenalan — Khusus 10 Klien Pertama Khania Studio',
  primaryCta: 'Konsultasikan Website Saya',
  secondaryCta: 'Lihat Contoh Website',
  trustMicrocopy: 'Konsultasi Gratis • Harga Transparan • Desain Fleksibel • Mobile Responsive',
};

export const THREE_BENEFITS = {
  heading: 'Kenapa Membuat Website di Khania Studio?',
  subheading: 'Website profesional tidak harus mahal, rumit, atau menunggu berminggu-minggu.',
  items: [
    {
      id: 'fast-delivery',
      number: '01',
      title: 'Pengerjaan Cepat',
      description:
        'Tidak perlu menunggu berminggu-minggu untuk memiliki website. Kami menggunakan workflow modern untuk mempercepat proses desain dan pembuatan website tanpa mengabaikan kualitas.',
      subtext: 'Estimasi pengerjaan menyesuaikan paket dan kompleksitas website.',
      badgeText: 'Mulai 1 - 24 Jam',
    },
    {
      id: 'custom-reference',
      number: '02',
      title: 'Desain Sesuai Referensi Anda',
      description:
        'Punya website, template, atau layout yang Anda suka? Kirimkan link atau screenshot-nya. Kami akan menggunakannya sebagai inspirasi dan menyesuaikan desain dengan logo, warna, konten, dan karakter bisnis Anda.',
      subtext: 'Referensi → Customisasi → Website Anda',
      badgeText: 'Desain Fleksibel',
    },
    {
      id: 'affordable-transparent',
      number: '03',
      title: 'Harga Terjangkau & Transparan',
      description:
        'Pilih paket sesuai kebutuhan dan anggaran bisnis Anda. Harga dijelaskan sejak awal sehingga Anda mengetahui apa yang akan didapatkan.',
      subtext: 'Mulai Rp399.000 tanpa biaya tersembunyi.',
      badgeText: 'Mulai Rp399.000',
    },
  ],
};

export const PORTFOLIO_PROJECTS: PortfolioProject[] = [
  {
    id: 'tanur-jatiasih',
    category: 'TRAVEL UMROH & HAJI',
    badge: 'REAL BUSINESS PROJECT',
    badgeType: 'real',
    title: 'Tanur Muthmainnah Tour — Jatiasih',
    description:
      'Website layanan perjalanan Umroh & Haji yang dirancang untuk menampilkan profil dan legalitas travel, paket perjalanan, fasilitas, edukasi calon jamaah, serta memudahkan pengunjung berkonsultasi melalui WhatsApp.',
    features: [
      'Responsive Design',
      'Paket Umroh & Haji',
      'WhatsApp Integration',
      'Artikel',
      'Galeri',
      'Conversion CTA',
    ],
    url: 'https://tanurjatiasih.my.id/',
    ctaText: 'Lihat Live Website',
    imagePlaceholder: 'tanur',
    stats: [
      { label: 'Tipe Website', value: 'Travel & Service' },
      { label: 'Integrasi CTA', value: 'Direct WhatsApp' },
    ],
  },
  {
    id: 'casa-loka',
    category: 'PROPERTY / REAL ESTATE',
    badge: 'DEMO / CONCEPT PROJECT',
    badgeType: 'demo',
    title: 'Casa Loka Residence',
    description:
      'Demo website pemasaran properti dengan konsep premium untuk menunjukkan bagaimana website developer property dapat menampilkan tipe rumah, fasilitas, harga, lokasi, FAQ, dan mengarahkan calon pembeli untuk menghubungi sales.',
    features: [
      'Premium Property Design',
      'Property Showcase',
      'Price Information',
      'WhatsApp CTA',
      'FAQ',
      'Responsive Design',
    ],
    url: 'https://casa-loka.vercel.app/',
    ctaText: 'Lihat Live Demo',
    note: 'Casa Loka Residence ditampilkan sebagai demo/concept project untuk menunjukkan kemampuan desain dan pengembangan website Khania Studio.',
    imagePlaceholder: 'casaloka',
    stats: [
      { label: 'Tipe Website', value: 'Property Showcase' },
      { label: 'Desain Layout', value: 'Modern & Clean' },
    ],
  },
];

export const DESIGN_REFERENCE_SECTION = {
  heading: 'Ada Website yang Desainnya Anda Suka?',
  subheading:
    'Tidak perlu menjelaskan desain dari nol. Cukup kirimkan link, screenshot, template, atau contoh website yang Anda sukai.',
  steps: [
    {
      step: '1',
      title: 'Kirim Referensi',
      desc: 'Website, screenshot, template, atau layout yang Anda minati.',
    },
    {
      step: '2',
      title: 'Kami Sesuaikan',
      desc: 'Warna, logo, konten, struktur, dan karakter unik bisnis Anda.',
    },
    {
      step: '3',
      title: 'Website Anda Dibuat',
      desc: 'Hasil akhirnya menjadi website profesional dengan identitas bisnis Anda sendiri.',
    },
  ],
  ctaText: 'Kirim Referensi via WhatsApp',
  microcopy:
    'Belum punya referensi? Tidak masalah. Kami dapat membantu menentukan gaya desain yang sesuai dengan bisnis Anda.',
};

export const SERVICES_LIST: ServiceItem[] = [
  {
    id: 'landing-page',
    title: 'Landing Page',
    description: 'Website satu halaman untuk promosi produk, jasa, campaign, atau mendapatkan leads.',
    iconName: 'Layout',
  },
  {
    id: 'website-umkm',
    title: 'Website UMKM',
    description: 'Website profesional untuk memperkenalkan bisnis, produk, layanan, lokasi, dan kontak.',
    iconName: 'Building',
  },
  {
    id: 'company-profile',
    title: 'Company Profile',
    description: 'Website untuk membangun kredibilitas perusahaan dan menampilkan profil, layanan, portfolio, serta informasi perusahaan.',
    iconName: 'FileText',
  },
  {
    id: 'website-property',
    title: 'Website Property',
    description: 'Website pemasaran property untuk menampilkan project, tipe unit, fasilitas, lokasi, harga, dan kontak sales.',
    iconName: 'Building2',
  },
  {
    id: 'website-travel',
    title: 'Website Travel',
    description: 'Website untuk menampilkan paket perjalanan, fasilitas, jadwal, informasi perusahaan, dan konsultasi pelanggan.',
    iconName: 'Plane',
  },
  {
    id: 'custom-business',
    title: 'Custom Business Website',
    description: 'Punya kebutuhan website lainnya? Konsultasikan kepada kami.',
    iconName: 'Sparkles',
  },
];

export const ORDER_STEPS: StepItem[] = [
  {
    number: '01',
    title: 'Ceritakan Kebutuhan Anda',
    description: 'Hubungi kami melalui WhatsApp dan ceritakan bisnis serta website yang ingin dibuat.',
    iconName: 'MessageSquare',
  },
  {
    number: '02',
    title: 'Tentukan Desain',
    description: 'Kirim contoh website yang Anda sukai atau biarkan kami membantu menentukan desain yang sesuai.',
    iconName: 'Palette',
  },
  {
    number: '03',
    title: 'Kirim Materi Website',
    description: 'Kirim logo, profil bisnis, produk/jasa, foto, kontak, dan informasi lain yang ingin ditampilkan.',
    iconName: 'FolderUp',
  },
  {
    number: '04',
    title: 'Website Dibuat & Online',
    description: 'Setelah desain dan materi disepakati, kami mulai mengerjakan website hingga siap digunakan.',
    iconName: 'CheckCircle2',
  },
];

export const PRICING_PACKAGES: PricingPackage[] = [
  {
    id: 'starter',
    name: 'STARTER',
    normalPrice: 'Rp450.000',
    promoPrice: 'Rp399.000',
    badge: 'KHUSUS 10 KLIEN PERTAMA',
    badgeColor: 'bg-emerald-500/10 text-emerald-700 border-emerald-500/20',
    targetAudience: 'Cocok untuk landing page sederhana dan bisnis yang baru mulai online.',
    deliveryTime: 'Mulai 1–24 jam*',
    features: [
      '1 Landing Page',
      'Professional Design',
      'Mobile Responsive',
      'WhatsApp Button',
      'Contact Form',
      'Basic SEO',
      'SSL Certificate',
      'Hosting 1 Tahun',
      '1x Revisi Minor',
    ],
    note: 'Domain ekonomis mengikuti ketentuan paket. Upgrade domain .com tersedia mulai +Rp100.000',
    waMessage:
      'Halo Khania Studio, saya tertarik dengan Paket Starter Rp399.000. Saya ingin konsultasi mengenai website untuk bisnis saya.',
  },
  {
    id: 'bronze',
    name: 'BRONZE',
    normalPrice: 'Rp780.000',
    promoPrice: 'Rp699.000',
    badge: 'COCOK UNTUK UMKM',
    badgeColor: 'bg-slate-500/10 text-slate-700 border-slate-500/20',
    targetAudience: 'Cocok untuk UMKM yang membutuhkan website profil bisnis dengan informasi produk & layanan.',
    deliveryTime: 'Mulai 1–24 jam*',
    features: [
      'Up to 3 Halaman Utama',
      'Professional Design',
      'Mobile Responsive',
      'WhatsApp Integration',
      'Contact Form',
      'Basic SEO Setup',
      'SSL Certificate',
      'Free Hosting 1 Tahun',
      'Free Domain Ekonomis',
      '2x Revisi Minor',
    ],
    waMessage:
      'Halo Khania Studio, saya tertarik dengan Paket Bronze Rp699.000. Saya ingin konsultasi mengenai website untuk bisnis saya.',
  },
  {
    id: 'silver',
    name: 'SILVER',
    normalPrice: 'Rp1.580.000',
    promoPrice: 'Rp1.390.000',
    badge: 'PALING DIREKOMENDASIKAN',
    badgeColor: 'bg-indigo-600 text-white border-indigo-600',
    isPopular: true,
    targetAudience: 'Cocok untuk bisnis yang membutuhkan website lebih lengkap dan kredibel.',
    deliveryTime: '24–48 jam*',
    features: [
      'Up to 5 Halaman',
      'Custom Professional Design',
      'Mobile Responsive',
      'WhatsApp Button & Direct Chat',
      'Free Domain .com 1 Tahun',
      'Premium Hosting 1 Tahun',
      'Basic Copywriting Support',
      'Form Inquiry & Google Maps',
      'Google Analytics & Basic SEO',
      '3x Revisi Minor',
    ],
    waMessage:
      'Halo Khania Studio, saya tertarik dengan Paket Silver Rp1.390.000. Saya ingin konsultasi mengenai website untuk bisnis saya.',
  },
  {
    id: 'gold',
    name: 'GOLD',
    normalPrice: 'Rp2.400.000',
    promoPrice: 'Rp2.090.000',
    badge: 'LEBIH KOMPLEKS',
    badgeColor: 'bg-amber-500/10 text-amber-800 border-amber-500/20',
    targetAudience: 'Cocok untuk website profesional dengan halaman dan kebutuhan lebih kompleks.',
    deliveryTime: '24–72 jam*',
    features: [
      'Up to 10 Halaman',
      'Premium Custom Design',
      'Mobile Responsive',
      'WhatsApp Integration & Multi CTA',
      'Free Domain .com 1 Tahun',
      'High Speed Hosting 1 Tahun',
      'Full Content & Copywriting Setup',
      'Blog/Article Section Setup',
      'Speed Optimization & Advanced SEO',
      'Priority Support & 5x Revisi',
    ],
    waMessage:
      'Halo Khania Studio, saya tertarik dengan Paket Gold Rp2.090.000. Saya ingin konsultasi mengenai website untuk bisnis saya.',
  },
];

export const PRICING_DISCLAIMER =
  'Harga promo berlaku untuk Program 10 Klien Pertama Khania Studio. Harga dan ruang lingkup pekerjaan dikonfirmasi sebelum pengerjaan dimulai.';

export const DELIVERY_ESTIMATES = [
  { package: 'Starter', time: 'Mulai 1–24 jam*' },
  { package: 'Bronze', time: 'Mulai 1–24 jam*' },
  { package: 'Silver', time: '24–48 jam*' },
  { package: 'Gold', time: '24–72 jam*' },
];

export const DELIVERY_NOTE =
  '*Estimasi pengerjaan dihitung setelah desain disepakati dan seluruh materi yang dibutuhkan telah lengkap. Waktu dapat berubah sesuai kompleksitas dan permintaan revisi.';

export const FAQ_LIST: FAQItem[] = [
  {
    id: 'faq-1',
    question: 'Apakah saya harus membeli domain dan hosting sendiri?',
    answer:
      'Tidak harus. Kami menyediakan paket yang dapat mencakup hosting dan domain sesuai jenis paket yang dipilih.',
  },
  {
    id: 'faq-2',
    question: 'Saya belum punya desain website. Apakah tetap bisa pesan?',
    answer:
      'Bisa. Ceritakan jenis bisnis dan website yang Anda butuhkan. Kami dapat membantu menentukan gaya desain yang sesuai.',
  },
  {
    id: 'faq-3',
    question: 'Saya punya contoh website yang saya suka. Apakah bisa dibuat seperti itu?',
    answer:
      'Bisa dijadikan referensi. Kami akan mempelajari gaya layout dan struktur yang Anda sukai, kemudian menyesuaikannya dengan identitas, konten, dan kebutuhan bisnis Anda.',
  },
  {
    id: 'faq-4',
    question: 'Apakah website akan sama persis dengan website referensi?',
    answer:
      'Tidak. Website referensi digunakan sebagai inspirasi desain. Logo, konten, foto, identitas brand, dan elemen unik milik pihak lain tidak disalin.',
  },
  {
    id: 'faq-5',
    question: 'Apa saja yang perlu saya siapkan?',
    answer:
      'Umumnya logo, profil bisnis, daftar produk atau jasa, foto, alamat, nomor WhatsApp, media sosial, dan informasi lain yang ingin ditampilkan.',
  },
  {
    id: 'faq-6',
    question: 'Apakah website bisa dibuka melalui HP?',
    answer:
      'Ya. Website dibuat responsif agar nyaman digunakan melalui smartphone, tablet, maupun komputer.',
  },
  {
    id: 'faq-7',
    question: 'Berapa lama website selesai?',
    answer:
      'Tergantung paket, jumlah halaman, kompleksitas desain, kesiapan materi, dan revisi. Website sederhana dapat mulai dikerjakan dengan estimasi 1–24 jam setelah seluruh materi lengkap dan desain disepakati.',
  },
  {
    id: 'faq-8',
    question: 'Apakah saya bisa konsultasi sebelum memesan?',
    answer:
      'Bisa. Konsultasi awal gratis dan tidak ada kewajiban membeli.',
  },
];

export const FINAL_CTA_CONTENT = {
  heading: 'Siap Punya Website Profesional untuk Bisnis Anda?',
  text: 'Ceritakan bisnis Anda dan website seperti apa yang Anda inginkan. Jika punya contoh desain yang disukai, kirimkan kepada kami. Kami akan membantu menentukan solusi dan paket yang sesuai dengan kebutuhan serta anggaran Anda.',
  highlight: 'Program 10 Klien Pertama — Mulai Rp399.000',
  primaryCta: 'Konsultasikan Website Saya via WhatsApp',
  secondaryCta: 'Lihat Portfolio',
  microcopy: 'Konsultasi Gratis • Tanpa Kewajiban Membeli',
};

export const BLOG_POSTS: BlogPost[] = [
  {
    id: 'blog-1',
    title: '5 Elemen Penting Website UMKM yang Efektif Menghasilkan Penjualan',
    excerpt:
      'Memiliki website bukan hanya sekadar tampil online, melainkan cara membangun kepercayaan calon pelanggan secara konsisten.',
    readTime: '3 min baca',
    date: '10 Ags 2026',
    author: 'Tim Khania Studio',
    category: 'Edukasi Website',
    content: [
      'Bagi pemilik bisnis UMKM, website sering kali menjadi titik sentuh pertama calon konsumen sebelum memutuskan untuk membeli atau berkonsultasi via WhatsApp.',
      '1. Tombol WhatsApp yang Mudah Ditemukan: Sebagian besar pelanggan Indonesia lebih suka bertransaksi secara personal via chat. Pastikan tombol WA terlihat jelas di setiap halaman.',
      '2. Kejelasan Penawaran & Layanan: Dalam 3-5 detik pertama, pengunjung harus paham apa yang Anda tawarkan dan apa keunggulannya.',
      '3. Desain Responsif Mobile: Lebih dari 80% calon pembeli membuka website melalui smartphone.',
      '4. Bukti Kualitas / Legalitas: Tampilkan portfolio, lokasi fisik, atau legalitas bisnis Anda untuk menghilangkan ragu.',
      '5. Kecepatan Loading: Website yang cepat dibuka mencegah calon pelanggan berpindah ke kompetitor.',
    ],
  },
  {
    id: 'blog-2',
    title: 'Mengapa Menggunakan Referensi Website Sangat Mempercepat Proses Desain?',
    excerpt:
      'Mengirimkan contoh website favorit Anda membantu kami memahami selera visual dan ekspektasi struktur tanpa perdebatan rumit.',
    readTime: '4 min baca',
    date: '05 Ags 2026',
    author: 'Tim Khania Studio',
    category: 'Panduan Desain',
    content: [
      'Banyak pemilik bisnis merasa bingung saat ditanya: "Desain seperti apa yang Anda inginkan?". Menggambarkan konsep visual dengan kata-kata sering kali menghasilkan persepsi berbeda.',
      'Dengan mengirimkan contoh link website, screenshot, atau layout yang Anda sukai, kami dapat langsung menangkap arah visual yang Anda inginkan.',
      'Kami menggunakannya sebagai acuan inspirasi layout dan tata letak, lalu menyesuaikannya dengan skema warna, identitas logo, serta narasi bisnis unik Anda sendiri tanpa menjiplak.',
    ],
  },
  {
    id: 'blog-3',
    title: 'Pentingnya Memiliki Domain Custom (.com) untuk Reputasi Bisnis Anda',
    excerpt:
      'Gunakan alamat website profesional agar brand Anda terlihat lebih terpercaya dan serius dibanding menggunakan subdomain gratisan.',
    readTime: '3 min baca',
    date: '28 Jul 2026',
    author: 'Tim Khania Studio',
    category: 'Branding & Domain',
    content: [
      'Nama domain ibarat alamat toko fisik Anda di dunia digital. Memiliki domain seperti nama-bisnis-anda.com memberikan kesan profesionalisme yang instan.',
      'Studi menunjukkan calon pembeli cenderung lebih percaya untuk mentransfer pembayaran ke bisnis yang memiliki domain independen resmi dibanding toko yang hanya mengandalkan media sosial atau subdomain gratisan.',
      'Paket Silver dan Gold di Khania Studio sudah mencakup pendaftaran domain .com gratis selama 1 tahun penuh.',
    ],
  },
];
