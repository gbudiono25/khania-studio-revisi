KHANIA STUDIO — DEBUG VERIFIKASI PEMBAYARAN (BROWSER)
========================================================

SQL debug sudah berhasil dibuat di Supabase. Screenshot "Success. No rows
returned" berarti CREATE FUNCTION/GRANT berhasil; itu BELUM menjalankan
function debug.

File ini digunakan untuk memanggil function debug dari sesi browser Admin.

LANGKAH:
1. Upload admin-verify-payment-debug.html ke root hosting.
2. Login ke Admin Panel pada browser yang sama.
3. Buka:
   https://khania-studio.com/admin-verify-payment-debug.html
4. Tunggu hasil.
5. Kirim screenshot hasilnya.

Order yang dites:
KS-260922-8170

Function debug:
admin_verify_payment_debug(uuid)

Function tersebut:
- memeriksa admin session;
- memeriksa order/payment;
- menjalankan UPDATE orders dan payments;
- sengaja melakukan ROLLBACK;
- mengembalikan SQLSTATE/message jika UPDATE gagal.

Jadi status order/payment TIDAK akan berubah.

Setelah diagnosis selesai, file HTML diagnostic sebaiknya dihapus dari hosting.
Jangan kirim credential atau secret key.
