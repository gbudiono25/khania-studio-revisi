const orders = [
  {
    orderNumber:"KS-260922-1AED", clientCode:"001-ST-09-2026",
    name:"Budi Santoso", business:"ABC Furniture", email:"budi@example.com",
    package:"Starter", total:500000, payment:"Pembayaran Terverifikasi",
    brief:"Belum Dikirim", date:"22 Sep 2026"
  },
  {
    orderNumber:"KS-260922-85CA", clientCode:"002-BR-09-2026",
    name:"Siti Rahma", business:"Rahma Beauty", email:"siti@example.com",
    package:"Bronze", total:780000, payment:"Menunggu Verifikasi Pembayaran",
    brief:"Belum Dikirim", date:"22 Sep 2026"
  },
  {
    orderNumber:"KS-260922-8170", clientCode:"003-SV-09-2026",
    name:"Andi Wijaya", business:"Wijaya Consultant", email:"andi@example.com",
    package:"Silver", total:1500000, payment:"Menunggu Pembayaran",
    brief:"Belum Dikirim", date:"22 Sep 2026"
  }
];

let selected = null;

const $ = id => document.getElementById(id);
const rupiah = n => "Rp" + n.toLocaleString("id-ID");

function paymentClass(v){
  if(v === "Pembayaran Terverifikasi") return "paid";
  if(v === "Menunggu Verifikasi Pembayaran") return "waiting";
  return "danger";
}
function briefClass(v){ return v === "Belum Dikirim" ? "waiting" : "brief"; }

function render(){
  const q = $("search").value.toLowerCase().trim();
  const pf = $("paymentFilter").value;
  const bf = $("briefFilter").value;
  const rows = orders.filter(o =>
    (!q || [o.orderNumber,o.clientCode,o.name,o.business,o.email,o.package].join(" ").toLowerCase().includes(q)) &&
    (pf === "ALL" || o.payment === pf) &&
    (bf === "ALL" || o.brief === bf)
  );
  $("ordersBody").innerHTML = rows.map(o => `
    <tr>
      <td><span class="order-no">${o.orderNumber}</span><span class="sub">${o.clientCode}</span></td>
      <td><strong>${o.name}</strong><span class="sub">${o.business}</span></td>
      <td>${o.package}</td>
      <td><strong>${rupiah(o.total)}</strong></td>
      <td><span class="badge ${paymentClass(o.payment)}">${o.payment}</span></td>
      <td><span class="badge ${briefClass(o.brief)}">${o.brief}</span></td>
      <td>${o.date}</td>
      <td><div class="row-actions">
        <button class="icon-btn" data-action="detail" data-id="${o.orderNumber}">Detail</button>
        <button class="icon-btn" ${o.payment !== "Pembayaran Terverifikasi" ? "disabled" : ""} data-action="brief" data-id="${o.orderNumber}">
          ${o.brief === "Form Brief Dikirim" ? "Kirim Ulang" : "Kirim Brief"}
        </button>
      </div></td>
    </tr>`).join("");
  $("empty").classList.toggle("hidden", rows.length !== 0);
  updateSummary();
}
function updateSummary(){
  $("sumTotal").textContent = orders.length;
  $("sumPending").textContent = orders.filter(o=>o.payment==="Menunggu Pembayaran").length;
  $("sumVerify").textContent = orders.filter(o=>o.payment==="Menunggu Verifikasi Pembayaran").length;
  $("sumPaid").textContent = orders.filter(o=>o.payment==="Pembayaran Terverifikasi").length;
}
function showDetail(order){
  selected = order;
  $("detailTitle").textContent = order.orderNumber;
  $("detailSubtitle").textContent = `${order.name} — ${order.business}`;
  $("detailContent").innerHTML = [
    ["Kode Klien/Project",order.clientCode],["Paket",order.package],
    ["Total Tagihan",rupiah(order.total)],["Email",order.email],
    ["Status Pembayaran",order.payment],["Status Form Brief",order.brief],
    ["Tanggal Order",order.date],["WhatsApp","Data dari order"]
  ].map(([a,b])=>`<div class="detail-item"><label>${a}</label><strong>${b}</strong></div>`).join("");
  const can = order.payment === "Pembayaran Terverifikasi";
  $("detailBriefBtn").disabled = !can;
  $("detailBriefBtn").textContent = order.brief === "Form Brief Dikirim" ? "Kirim Ulang Form Brief" : "Kirim Form Brief";
  $("detailModal").classList.remove("hidden");
}
function showBrief(order){
  selected = order;
  const ok = order.payment === "Pembayaran Terverifikasi";
  $("briefGate").className = "gate " + (ok ? "ok" : "no");
  $("briefGate").textContent = ok
    ? "✓ Pembayaran sudah terverifikasi. Form Brief dapat dikirim ke klien."
    : "Form Brief belum dapat dikirim karena pembayaran belum terverifikasi.";
  $("briefPreview").innerHTML = ok ? `
    <strong>Pratinjau email</strong><br><br>
    Kepada: ${order.name} &lt;${order.email}&gt;<br>
    Subject: KHANIA STUDIO — Form Brief Website Anda Siap Diisi<br><br>
    Nomor Order: <strong>${order.orderNumber}</strong><br>
    Kode Klien/Project: <strong>${order.clientCode}</strong><br>
    Paket: <strong>${order.package}</strong><br><br>
    Email akan berisi tombol <strong>ISI FORM BRIEF WEBSITE</strong>.
  ` : "Email tidak dapat dikirim pada status pembayaran ini.";
  $("sendBriefBtn").disabled = !ok;
  $("briefModal").classList.remove("hidden");
}
function toast(msg){
  $("toast").textContent = msg;
  $("toast").classList.remove("hidden");
  setTimeout(()=> $("toast").classList.add("hidden"), 3200);
}

document.addEventListener("click", e => {
  const action = e.target.closest("[data-action]");
  if(action){
    const o = orders.find(x=>x.orderNumber===action.dataset.id);
    if(action.dataset.action==="detail") showDetail(o);
    if(action.dataset.action==="brief") showBrief(o);
  }
  const close = e.target.closest("[data-close]");
  if(close) $(close.dataset.close).classList.add("hidden");
});
$("detailBriefBtn").addEventListener("click", ()=>{
  $("detailModal").classList.add("hidden");
  if(selected) showBrief(selected);
});
$("sendBriefBtn").addEventListener("click", ()=>{
  if(!selected || selected.payment !== "Pembayaran Terverifikasi") return;
  const firstSend = selected.brief === "Belum Dikirim";
  selected.brief = "Form Brief Dikirim";
  $("briefModal").classList.add("hidden");
  render();
  toast(firstSend ? `Form Brief ${selected.orderNumber} siap dikirim (mode demo).` : `Form Brief ${selected.orderNumber} siap dikirim ulang (mode demo).`);
});
["search","paymentFilter","briefFilter"].forEach(id=>$(id).addEventListener("input",render));
$("resetBtn").addEventListener("click",()=>{
  $("search").value="";$("paymentFilter").value="ALL";$("briefFilter").value="ALL";render();
});
updateSummary(); render();
