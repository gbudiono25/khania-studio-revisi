KHANIA STUDIO — ADMIN PESANAN STAGE 2 (UI PROTOTYPE)

Isi:
- admin-pesanan.html
- css/admin-pesanan.css
- js/admin-pesanan.js

Tujuan:
Prototype tampilan dan interaksi halaman Admin → Pesanan sebelum disambungkan ke Supabase.

Yang sudah bisa diuji:
1. Daftar pesanan.
2. Ringkasan jumlah order berdasarkan status pembayaran.
3. Pencarian order/klien/bisnis.
4. Filter status pembayaran.
5. Filter status Form Brief.
6. Detail order.
7. Tombol "Kirim Form Brief" hanya aktif bila status pembayaran:
   "Pembayaran Terverifikasi".
8. Tombol berubah menjadi "Kirim Ulang" setelah simulasi pengiriman.
9. Preview email Form Brief.
10. Responsive untuk desktop/tablet/mobile.

CATATAN PENTING:
- Ini masih PROTOTYPE UI, belum terhubung ke Supabase.
- Data pada JavaScript adalah data demo untuk pengujian tampilan.
- Tombol pengiriman saat ini hanya mensimulasikan perubahan status di browser.
- Belum mengirim email nyata.
- Belum membuat token/link Form Brief nyata.
- Jangan mengganti file produksi Order/Payment dengan prototype ini.

Tahap implementasi berikutnya:
A. Ambil data orders/clients/packages dari Supabase.
B. Ambil status pembayaran aktual.
C. Hubungkan tombol "Kirim Form Brief" ke endpoint server.
D. Server memastikan payment_status = verified.
E. Server membuat/reuse website_briefs + secure token.
F. Server mengirim email melalui SMTP.
G. Simpan sent_at, sent_to, sent_by dan status brief.
H. Tambahkan tombol "Kirim Ulang" dengan audit log.

Prototype ini sengaja dipisahkan agar alur Order + Payment yang sudah berhasil tidak terganggu.
