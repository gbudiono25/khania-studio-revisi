KHANIA STUDIO — SupabaseClient Query Fix V2

Root cause confirmed by Diagnostic 3: PostgREST expects filters as query parameters such as order_number=eq.KS-... .
The previous patch incorrectly produced order_number=eq=KS-..., because it encoded the operator into the parameter name.

This V2 patch changes select/update filter construction to:
  $params[$col] = 'eq.' . $val;
  $params[$col] = 'is.null';

Upload ONLY SupabaseClient.php to:
/public_html/lib/SupabaseClient.php

Do not change SQL, proses-formulir.php, or other files yet.
After upload, retest Diagnostic 3. Expected HTTP 200 and the order row should be found.
Delete diagnostic file after testing.
