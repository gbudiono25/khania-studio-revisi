KHANIA STUDIO — SupabaseClient Query Fix

Root cause confirmed by Diagnostic 3:
PostgREST returned HTTP 400 PGST100 because the filter was sent as:
    order_number=eq=KS-260922-85CA
instead of:
    order_number=eq.KS-260922-85CA

The previous SupabaseClient used http_build_query() with parameter names such as
"order_number=eq". PHP encoded the '=' in the parameter name to %3D, producing
an invalid PostgREST filter.

Patch included:
- SupabaseClient.php
- Adds buildQueryString() that preserves '=' in PostgREST operator keys.
- Uses it for normal REST requests and GET RPC query strings.
- No database/schema changes.
- No changes to order/payment/brief business logic.

Upload only:
    SupabaseClient.php

Destination:
    /public_html/lib/SupabaseClient.php

The file passed PHP syntax check.

After upload:
1. Re-run the brief diagnostic if desired.
2. Test the actual Form Brief V3 submission for the verified order.
3. If successful, remove the diagnostic PHP files from public_html.
