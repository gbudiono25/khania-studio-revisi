KHANIA STUDIO — DIAGNOSTIC ADMIN FORM BRIEF V2

Upload diagnose-admin-form-brief-v2.html ke /public_html/
Buka https://khania-studio.com/diagnose-admin-form-brief-v2.html
Login Admin harus tetap aktif. Tes read-only, tidak mengubah Supabase.
Kirim screenshot hasil langkah 1-7.
