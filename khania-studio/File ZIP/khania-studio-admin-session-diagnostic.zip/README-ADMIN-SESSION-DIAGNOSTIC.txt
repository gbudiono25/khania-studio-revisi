KHANIA STUDIO — DIAGNOSTIC SESSION ADMIN
==========================================

Tujuan:
Menguji konteks login BROWSER secara langsung, bukan SQL Editor.

File:
admin-session-diagnostic.html

PENTING:
File ini READ-ONLY. Tidak melakukan INSERT, UPDATE, DELETE, ALTER,
DROP, atau CREATE.

LANGKAH:
1. Upload admin-session-diagnostic.html ke root hosting Khania Studio.
2. Pastikan api/supabase-config.php sudah ada (sama seperti Admin Panel).
3. Login dahulu ke admin-pesanan.html sebagai admin.
4. Pada browser yang sama buka:
   https://khania-studio.com/admin-session-diagnostic.html
5. Catat/screenshot hasil:
   - Auth UID
   - Profile ID
   - Profile Role
   - is_admin() dari sesi browser
   - error jika ada
6. Kirim screenshot hasilnya.

SETELAH SELESAI:
File diagnostic boleh dihapus dari hosting. Jangan jadikan file ini
sebagai bagian permanen Admin Area.

Tidak perlu mengirim credential, API key, atau password.
