KHANIA STUDIO — Stage 2D2 Final Fix

Root cause confirmed: current hosting proses-formulir.php still passed string filters to SupabaseClient::select(), whose third argument requires an array. This caused HTTP 500 after the SupabaseClient query fix.

Patched only these three filters:
- orders: ['order_number' => $orderId]
- clients: ['id' => $orderRecord['client_id']]
- packages: ['id' => $orderRecord['package_id']]

No SQL, HTML, order flow, payment flow, or SupabaseClient changes.

Upload only proses-formulir.php to /public_html/proses-formulir.php, replacing the current file. Then test the existing Client Brief link.
