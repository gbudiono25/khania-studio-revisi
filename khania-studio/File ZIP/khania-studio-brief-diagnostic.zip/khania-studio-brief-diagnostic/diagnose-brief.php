<?php
// KHANIA STUDIO — CLIENT BRIEF DIAGNOSTIC
// Temporary diagnostic. READ-ONLY. DELETE AFTER TESTING.
// Does not display any secret/key/password or client PII.

header('Content-Type: text/plain; charset=utf-8');

$root = __DIR__;
$orderNumber = trim((string)($_GET['order'] ?? 'KS-260922-85CA'));

function line($label, $value) {
    echo str_pad($label, 42) . $value . "\n";
}
function yesno($v) { return $v ? 'YES' : 'NO'; }
function rest_get($url, $apiKey) {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            'apikey: ' . $apiKey,
            'Authorization: Bearer ' . $apiKey,
            'Accept: application/json',
        ],
        CURLOPT_TIMEOUT => 20,
        CURLOPT_CONNECTTIMEOUT => 10,
    ]);
    $body = curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    return [$status, $body, $error];
}

try {
    require_once $root . '/lib/env.php';
    loadEnv($root . '/.env');
} catch (Throwable $e) {
    echo "=== CLIENT BRIEF DIAGNOSTIC ===\n";
    echo "ENV LOAD ERROR\n";
    echo get_class($e) . ': ' . $e->getMessage() . "\n";
    exit;
}

$url = rtrim((string)getenv('SUPABASE_URL'), '/');
$anon = (string)getenv('SUPABASE_ANON_KEY');
$service = (string)getenv('SUPABASE_SERVICE_ROLE_KEY');

if ($orderNumber === '' || !preg_match('/^[A-Za-z0-9-]+$/', $orderNumber)) {
    $orderNumber = 'INVALID';
}

$filter = rawurlencode($orderNumber);

// Detect whether the deployed PHP has the Stage 2D-2 array-filter fix.
$processPath = $root . '/proses-formulir.php';
$processText = is_file($processPath) ? (string)file_get_contents($processPath) : '';
$hasArrayOrderFilter = (bool)preg_match(
    "/'orders'\\s*,\\s*'id,order_number,client_id,package_id,status,order_date'\\s*,\\s*\\[\\s*'order_number'\\s*=>/s",
    $processText
);
$hasStringOrderFilter = (bool)preg_match(
    "/'orders'\\s*,\\s*'id,order_number,client_id,package_id,status,order_date'\\s*,\\s*'order_number=eq\\./s",
    $processText
);

echo "=== KHANIA STUDIO — CLIENT BRIEF DIAGNOSTIC ===\n\n";
line('PHP Version:', PHP_VERSION);
line('Script:', basename(__FILE__));
line('Order under test:', $orderNumber);
line('SUPABASE_URL:', $url !== '' ? 'TERISI' : 'KOSONG');
line('SUPABASE_ANON_KEY:', $anon !== '' ? 'TERISI' : 'KOSONG');
line('SUPABASE_SERVICE_ROLE_KEY:', $service !== '' ? 'TERISI' : 'KOSONG');
line('proses-formulir.php exists:', yesno(is_file($processPath)));
line('Stage 2D-2 array filter present:', yesno($hasArrayOrderFilter));
line('Old string filter still present:', yesno($hasStringOrderFilter));

echo "\n=== TEST 1: DIRECT ORDERS API ===\n";
if ($url === '' || $service === '') {
    echo "SKIPPED — Supabase URL or service role key is not loaded.\n";
} else {
    $endpoint = $url . '/rest/v1/orders?select=id,order_number,client_id,package_id,status,order_date&order_number=eq.' . $filter . '&limit=1';
    [$status, $body, $curlError] = rest_get($endpoint, $service);
    line('HTTP Status:', (string)$status);
    line('cURL Error:', $curlError !== '' ? $curlError : 'NONE');
    $decoded = json_decode((string)$body, true);
    if ($status >= 200 && $status < 300 && is_array($decoded)) {
        line('Rows returned:', (string)count($decoded));
        if (isset($decoded[0])) {
            line('Order found:', 'YES');
            line('Order ID:', (string)($decoded[0]['id'] ?? '(missing)'));
            line('Order status:', (string)($decoded[0]['status'] ?? '(missing)'));
            line('Client ID:', (string)($decoded[0]['client_id'] ?? '(missing)'));
            line('Package ID:', (string)($decoded[0]['package_id'] ?? '(missing)'));
        } else {
            line('Order found:', 'NO');
        }
    } else {
        line('Supabase response:', is_string($body) ? substr($body, 0, 500) : 'UNREADABLE');
    }
}

echo "\n=== TEST 2: SUPABASE CLIENT (CORRECT ARRAY FILTER) ===\n";
try {
    require_once $root . '/lib/SupabaseClient.php';
    $client = new \KhaniaStudio\SupabaseClient();
    $rows = $client->select(
        'orders',
        'id,order_number,client_id,package_id,status,order_date',
        ['order_number' => $orderNumber],
        1
    );
    line('select() result type:', gettype($rows));
    line('Rows returned:', is_array($rows) ? (string)count($rows) : 'NOT ARRAY');
    if (is_array($rows) && isset($rows[0])) {
        line('Order found via SupabaseClient:', 'YES');
        line('Order ID:', (string)($rows[0]['id'] ?? '(missing)'));
        line('Order status:', (string)($rows[0]['status'] ?? '(missing)'));
    } else {
        line('Order found via SupabaseClient:', 'NO');
    }
} catch (Throwable $e) {
    line('SupabaseClient error type:', get_class($e));
    line('SupabaseClient error:', $e->getMessage());
}

echo "\n=== TEST 3: WEBSITE BRIEF ===\n";
if ($url === '' || $service === '') {
    echo "SKIPPED — Supabase URL or service role key is not loaded.\n";
} else {
    // Look up the order UUID first, then inspect only brief metadata.
    $endpoint = $url . '/rest/v1/orders?select=id&order_number=eq.' . $filter . '&limit=1';
    [$status, $body, $curlError] = rest_get($endpoint, $service);
    $decoded = json_decode((string)$body, true);
    $orderId = is_array($decoded) && isset($decoded[0]['id']) ? $decoded[0]['id'] : '';
    if ($orderId === '') {
        echo "Cannot inspect website_briefs because order was not found.\n";
    } else {
        $briefEndpoint = $url . '/rest/v1/website_briefs?select=id,status,order_id,client_id,client_code&order_id=eq.' . rawurlencode($orderId) . '&limit=1';
        [$bStatus, $bBody, $bCurlError] = rest_get($briefEndpoint, $service);
        line('HTTP Status:', (string)$bStatus);
        line('cURL Error:', $bCurlError !== '' ? $bCurlError : 'NONE');
        $bDecoded = json_decode((string)$bBody, true);
        if ($bStatus >= 200 && $bStatus < 300 && is_array($bDecoded)) {
            line('Brief rows returned:', (string)count($bDecoded));
            if (isset($bDecoded[0])) {
                line('Brief found:', 'YES');
                line('Brief ID:', (string)($bDecoded[0]['id'] ?? '(missing)'));
                line('Brief status:', (string)($bDecoded[0]['status'] ?? '(missing)'));
                line('Brief client code:', (string)($bDecoded[0]['client_code'] ?? '(empty)'));
            } else {
                line('Brief found:', 'NO');
            }
        } else {
            line('Supabase response:', is_string($bBody) ? substr($bBody, 0, 500) : 'UNREADABLE');
        }
    }
}

echo "\n=== CONCLUSION GUIDE ===\n";
echo "1. Service role = KOSONG  -> .env is not being loaded.\n";
echo "2. Direct Orders API = NO -> order number is not found or database/API issue.\n";
echo "3. Direct Orders = YES but SupabaseClient = NO -> PHP client/env/filter problem.\n";
echo "4. Array filter = NO and old string filter = YES -> deployed proses-formulir.php is still the old version.\n";
echo "5. Orders = YES and Brief = YES -> the next failure is later in proses-formulir.php; then we inspect the next step.\n";
echo "\nDELETE THIS DIAGNOSTIC FILE AFTER TESTING.\n";
