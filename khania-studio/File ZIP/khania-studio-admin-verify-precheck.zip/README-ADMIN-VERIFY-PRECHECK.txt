KHANIA STUDIO — PRECHECK VERIFIKASI PEMBAYARAN
================================================

Tujuan:
Memeriksa dari SESI BROWSER ADMIN apakah order dan payment yang akan
diverifikasi dapat dibaca dan memiliki status yang sesuai.

Order yang diperiksa:
KS-260922-8170

READ-ONLY:
- Tidak memanggil admin_verify_payment()
- Tidak mengubah orders
- Tidak mengubah payments
- Tidak INSERT/UPDATE/DELETE/ALTER/DROP/CREATE

LANGKAH:
1. Upload admin-verify-precheck.html ke root hosting.
2. Login ke Admin Panel pada browser yang sama.
3. Buka:
   https://khania-studio.com/admin-verify-precheck.html
4. Kirim screenshot hasilnya.

SETELAH SELESAI:
File diagnostic dapat dihapus dari hosting.
Jangan kirim credential atau secret key.
