<?php
declare(strict_types=1);

/*
 * Khania Studio — proses-formulir.php
 * Server-side handler for the website request form.
 *
 * IMPORTANT:
 * - Put this file in the same folder as formulir-permintaan-website-khania-studio-v2.html
 * - PHP mail() must be enabled by the hosting provider.
 * - Keep internal/admin addresses in this PHP file only; never expose them in public HTML.
 */

const ADMIN_EMAIL = 'admin@khania-studio.com';
const INTERNAL_CC = 'gbudiono.25@gmail.com';
const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10 MB per file
const MAX_TOTAL_UPLOADS = 20;
const MAX_TOTAL_BYTES = 30 * 1024 * 1024; // 30 MB total

header('Content-Type: text/html; charset=UTF-8');

function fail(string $message, int $status = 400): never {
    http_response_code($status);
    $safe = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');
    echo '<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Pengiriman Gagal — Khania Studio</title><style>body{font:16px/1.6 Arial,sans-serif;background:#f1f5f9;color:#0f172a;margin:0}.wrap{max-width:700px;margin:10vh auto;padding:24px}.card{background:#fff;padding:28px;border-radius:16px;border:1px solid #dbe2ea}a{display:inline-block;background:#d4af37;color:#0f172a;padding:10px 16px;border-radius:9px;text-decoration:none;font-weight:700}</style></head><body><div class="wrap"><div class="card"><h1>Pengiriman belum berhasil</h1><p>'.$safe.'</p><a href="javascript:history.back()">Kembali ke formulir</a></div></div></body></html>';
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    fail('Metode akses tidak valid.', 405);
}

/* Simple honeypot anti-spam. Add <input name="website" ...> to the public form if desired. */
if (!empty($_POST['website'] ?? '')) {
    fail('Permintaan tidak dapat diproses.', 400);
}

function post(string $key): string {
    $value = $_POST[$key] ?? '';
    return is_string($value) ? trim($value) : '';
}

$package = post('package');
$siteType = post('siteType');
$pic = post('pic');
$picRole = post('picRole');
$picEmail = post('picEmail');
$picWhatsapp = post('picWhatsapp');
$businessName = post('businessName');
$businessCategory = post('businessCategory');
$businessDescription = post('businessDescription');
$targetAudience = post('targetAudience');
$primaryCTA = post('primaryCTA');
$approvalName = post('approvalName');

$required = [
    'Paket' => $package,
    'Jenis website' => $siteType,
    'Nama PIC' => $pic,
    'Peran PIC' => $picRole,
    'Email PIC' => $picEmail,
    'WhatsApp PIC' => $picWhatsapp,
    'Nama bisnis' => $businessName,
    'Bidang usaha' => $businessCategory,
    'Deskripsi bisnis' => $businessDescription,
    'Pelanggan utama' => $targetAudience,
    'CTA utama' => $primaryCTA,
    'Nama persetujuan' => $approvalName,
];

$missing = [];
foreach ($required as $label => $value) {
    if ($value === '') $missing[] = $label;
}
if ($missing) {
    fail('Field wajib belum lengkap: ' . implode(', ', $missing) . '.');
}

if (!filter_var($picEmail, FILTER_VALIDATE_EMAIL)) {
    fail('Alamat email PIC tidak valid.');
}

$allowedPackages = ['Starter','Bronze','Silver','Gold'];
if (!in_array($package, $allowedPackages, true)) {
    fail('Paket website tidak valid.');
}

$allowedTypes = [
    'Landing Page / Promo','UMKM / Bisnis Lokal','Company Profile',
    'Portfolio / Personal Branding','Jasa Profesional','Travel / Umroh / Haji',
    'Restaurant / Café','Hotel / Hospitality','Property / Real Estate',
    'Toko Online Sederhana','Lainnya'
];
if (!in_array($siteType, $allowedTypes, true)) {
    fail('Jenis website tidak valid.');
}

/* Collect POST fields, excluding consent checkboxes and arrays already handled below. */
$labels = [
    'package'=>'Paket Website',
    'siteType'=>'Jenis Website',
    'pic'=>'Nama Pemesan / PIC',
    'picRole'=>'Jabatan / Peran',
    'picEmail'=>'Email PIC',
    'picWhatsapp'=>'WhatsApp PIC',
    'picCity'=>'Kota Domisili',
    'businessName'=>'Nama Bisnis / Brand',
    'legalName'=>'Nama Legal',
    'businessCategory'=>'Bidang Usaha',
    'foundedYear'=>'Tahun Berdiri',
    'businessDescription'=>'Deskripsi Bisnis',
    'businessAddress'=>'Lokasi / Alamat Usaha',
    'serviceArea'=>'Area Layanan',
    'businessHours'=>'Jam Operasional',
    'targetAudience'=>'Pelanggan Utama',
    'companyHistory'=>'Sejarah / Perjalanan Perusahaan',
    'vision'=>'Visi',
    'mission'=>'Misi',
    'management'=>'Direksi / Komisaris / Manajemen',
    'businessUnits'=>'Unit Bisnis / Divisi',
    'companyCredentials'=>'Legalitas / Sertifikasi / Penghargaan / Pengalaman',
    'landingGoal'=>'Tujuan Utama Landing Page',
    'landingOffer'=>'Penawaran Utama',
    'landingCTA'=>'CTA Landing Page',
    'advantages'=>'Keunggulan Utama',
    'customerProblems'=>'Masalah / Kebutuhan Pelanggan',
    'solution'=>'Bagaimana Bisnis Menyelesaikan Masalah',
    'objections'=>'Keraguan / Pertanyaan Calon Pelanggan',
    'brandColors'=>'Warna Utama',
    'avoidColors'=>'Warna yang Dihindari',
    'fontStyle'=>'Gaya Font',
    'visualStyle'=>'Gaya Visual',
    'referenceUrl'=>'Link Website Referensi',
    'referenceNotes'=>'Bagian Referensi yang Disukai',
    'headline'=>'Headline',
    'subheadline'=>'Subheadline',
    'primaryCTA'=>'CTA Utama',
    'travelPackages'=>'Paket Perjalanan',
    'travelLicenses'=>'Legalitas / Izin Travel',
    'travelFacilities'=>'Fasilitas / Layanan / Bimbingan',
    'travelPayment'=>'Alur Pendaftaran / Pembayaran',
    'restaurantMenu'=>'Menu / Kategori Menu',
    'restaurantPrice'=>'Rentang Harga Restoran',
    'restaurantBooking'=>'Reservasi / Pemesanan',
    'hotelRooms'=>'Tipe Kamar',
    'hotelFacilities'=>'Fasilitas & Layanan Hotel',
    'hotelCapacity'=>'Jumlah Kamar / Kapasitas',
    'hotelBooking'=>'Reservasi Hotel',
    'propertyProject'=>'Nama Proyek',
    'propertyLocation'=>'Lokasi Proyek',
    'propertyArea'=>'Luas Kawasan',
    'propertyUnits'=>'Jumlah Unit',
    'propertyTypes'=>'Tipe Unit / Rumah',
    'propertyFacilities'=>'Fasilitas / Spesifikasi Properti',
    'propertyLegal'=>'Legalitas / Status Proyek',
    'credentials'=>'Kredibilitas / Legalitas / Sertifikasi / Pengalaman',
    'testimonials'=>'Testimonial Pelanggan',
    'assetNotes'=>'Catatan Penggunaan Aset',
    'bizWaPic'=>'PIC WhatsApp Bisnis',
    'bizWa'=>'WhatsApp Bisnis',
    'phonePic'=>'PIC Telepon',
    'phone'=>'Telepon',
    'bizEmail'=>'Email Bisnis',
    'instagram'=>'Instagram',
    'facebook'=>'Facebook',
    'tiktok'=>'TikTok',
    'youtube'=>'YouTube',
    'maps'=>'Google Maps',
    'publicAddress'=>'Alamat Lengkap Publik',
    'keywords'=>'Keyword SEO',
    'seoLocation'=>'Kota / Area Target SEO',
    'competitors'=>'Pesaing / Website Pembanding',
    'seoTopics'=>'Topik Artikel SEO',
    'specialRequests'=>'Informasi Tambahan / Permintaan Khusus',
    'approvalName'=>'Nama Persetujuan',
];

$lines = [];
foreach ($labels as $key => $label) {
    $value = post($key);
    if ($value !== '') {
        $lines[] = $label . ":\n" . $value;
    }
}

/* Product / service repeating fields */
$pn = $_POST['productName'] ?? [];
$pp = $_POST['productPrice'] ?? [];
$pd = $_POST['productDescription'] ?? [];
$pb = $_POST['productBenefit'] ?? [];

if (!is_array($pn)) $pn = [];
if (!is_array($pp)) $pp = [];
if (!is_array($pd)) $pd = [];
if (!is_array($pb)) $pb = [];

if (count($pn) > 50) {
    fail('Jumlah produk/jasa yang dikirim terlalu banyak.');
}
if ($pn) {
    $lines[] = "PRODUK / JASA:";
    foreach ($pn as $i => $name) {
        $name = trim((string)$name);
        if ($name === '') continue;
        $price = trim((string)($pp[$i] ?? ''));
        $desc  = trim((string)($pd[$i] ?? ''));
        $benef = trim((string)($pb[$i] ?? ''));
        $lines[] = sprintf(
            "%d. %s\n   Harga: %s\n   Deskripsi: %s\n   Keunggulan/Manfaat: %s",
            $i + 1,
            $name,
            $price !== '' ? $price : '-',
            $desc !== '' ? $desc : '-',
            $benef !== '' ? $benef : '-'
        );
    }
}

/* Uploaded files */
$attachments = [];
$totalBytes = 0;
$totalFiles = 0;

function addUploads(string $field, array &$attachments, int &$totalBytes, int &$totalFiles): void {
    if (!isset($_FILES[$field])) return;

    $f = $_FILES[$field];
    $names = $f['name'];
    if (!is_array($names)) {
        $names = [$f['name']]; 
        $f['tmp_name'] = [$f['tmp_name']];
        $f['error'] = [$f['error']];
        $f['size'] = [$f['size']];
        $f['type'] = [$f['type']];
    }

    foreach ($names as $i => $original) {
        $error = (int)($f['error'][$i] ?? UPLOAD_ERR_NO_FILE);
        if ($error === UPLOAD_ERR_NO_FILE) continue;
        if ($error !== UPLOAD_ERR_OK) fail('Salah satu file gagal diunggah. Silakan coba lagi.');
        $size = (int)($f['size'][$i] ?? 0);
        if ($size <= 0 || $size > MAX_FILE_SIZE) {
            fail('Ada file yang melebihi batas 10 MB per file.');
        }
        $tmp = (string)$f['tmp_name'][$i];
        if (!is_uploaded_file($tmp)) fail('Upload file tidak valid.');

        $ext = strtolower(pathinfo((string)$original, PATHINFO_EXTENSION));
        $allowed = ['jpg','jpeg','png','webp','gif','svg','pdf','doc','docx','xls','xlsx','mp4','mov','webm'];
        if (!in_array($ext, $allowed, true)) {
            fail('Tipe file tidak diperbolehkan: ' . htmlspecialchars((string)$original, ENT_QUOTES, 'UTF-8'));
        }

        $totalBytes += $size;
        $totalFiles++;
        if ($totalFiles > MAX_TOTAL_UPLOADS || $totalBytes > MAX_TOTAL_BYTES) {
            fail('Total file terlalu besar. Maksimal 20 file dan 30 MB per pengiriman.');
        }

        $attachments[] = [
            'path' => $tmp,
            'name' => preg_replace('/[^A-Za-z0-9._-]/', '_', basename((string)$original)),
            'type' => (string)($f['type'][$i] ?? 'application/octet-stream'),
        ];
    }
}

addUploads('referenceFiles', $attachments, $totalBytes, $totalFiles);
addUploads('testimonialPhoto', $attachments, $totalBytes, $totalFiles);
addUploads('logo', $attachments, $totalBytes, $totalFiles);
addUploads('businessImages', $attachments, $totalBytes, $totalFiles);
addUploads('videos', $attachments, $totalBytes, $totalFiles);
addUploads('documents', $attachments, $totalBytes, $totalFiles);
addUploads('productImage', $attachments, $totalBytes, $totalFiles);

if ($attachments) {
    $lines[] = "FILE TERLAMPIR:";
    foreach ($attachments as $a) $lines[] = "- " . $a['name'];
}

$submissionId = date('Ymd-His') . '-' . bin2hex(random_bytes(4));
$subject = 'Permintaan Website — ' . $businessName . ' — ' . $package . ' — ' . $submissionId;

$bodyText = "KHANIA STUDIO — PERMINTAAN WEBSITE\n";
$bodyText .= "ID SUBMISSION: " . $submissionId . "\n";
$bodyText .= "========================================\n\n";
$bodyText .= implode("\n\n", $lines);
$bodyText .= "\n\n========================================\n";
$bodyText .= "Pengiriman melalui formulir website Khania Studio.\n";

$from = ADMIN_EMAIL;
$replyTo = $picEmail;
$boundary = '=_Khania_' . md5((string)microtime(true));

$headers = [];
$headers[] = 'From: Khania Studio <' . $from . '>';
$headers[] = 'Reply-To: ' . $replyTo;
$headers[] = 'Cc: ' . INTERNAL_CC;
$headers[] = 'MIME-Version: 1.0';
$headers[] = 'Content-Type: multipart/mixed; boundary="' . $boundary . '"';

$message = "--{$boundary}\r\n";
$message .= "Content-Type: text/plain; charset=UTF-8\r\n";
$message .= "Content-Transfer-Encoding: 8bit\r\n\r\n";
$message .= $bodyText . "\r\n";

foreach ($attachments as $a) {
    $content = file_get_contents($a['path']);
    if ($content === false) continue;
    $encoded = chunk_split(base64_encode($content));
    $mime = $a['type'] !== '' ? $a['type'] : 'application/octet-stream';

    $message .= "--{$boundary}\r\n";
    $message .= "Content-Type: {$mime}; name=\"" . $a['name'] . "\"\r\n";
    $message .= "Content-Transfer-Encoding: base64\r\n";
    $message .= "Content-Disposition: attachment; filename=\"" . $a['name'] . "\"\r\n\r\n";
    $message .= $encoded . "\r\n";
}
$message .= "--{$boundary}--\r\n";

$sent = @mail($from, $subject, $message, implode("\r\n", $headers));

if (!$sent) {
    fail('Server menerima formulir, tetapi fungsi pengiriman email hosting belum aktif/terkonfigurasi. Silakan cek pengaturan email PHP pada hosting.', 500);
}

header('Location: konfirmasi-formulir.html?ref=' . rawurlencode($submissionId));
exit;
?>
