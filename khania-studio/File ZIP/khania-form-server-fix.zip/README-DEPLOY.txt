KHANIA STUDIO — SERVER FORM FIX

Upload these files/folders to the same public directory:
1. formulir-permintaan-website-khania-studio-v2.html
2. proses-formulir.php
3. konfirmasi-formulir.html
4. uploads-formulir/.htaccess

IMPORTANT:
- PHP must be enabled on the hosting.
- PHP mail() must be enabled/allowed by the hosting.
- The form action is relative to proses-formulir.php in the same directory.
- Test with a small submission first.
- If mail() is disabled, configure the host's mail/SMTP method before production use.

The handler validates required fields, accepts common web/business files, limits upload sizes,
emails the form data and uploaded files, then redirects to the confirmation page.
