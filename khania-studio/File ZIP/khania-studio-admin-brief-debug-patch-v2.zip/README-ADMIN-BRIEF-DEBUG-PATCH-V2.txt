KHANIA STUDIO — PATCH DEBUG KIRIM FORM BRIEF V2

Perubahan:
1. Jika terjadi error saat Kirim Form Brief, detail modal ditutup otomatis.
2. ErrorBox pada halaman Pesanan dibuka dan di-scroll agar langsung terlihat.
3. Response mentah dari admin-kirim-brief.php dibaca sehingga HTTP 500 non-JSON
   tetap dapat ditampilkan.

Upload:
 /public_html/js/admin-pesanan-live.js

Setelah upload:
1. Ctrl+F5 pada Admin Area.
2. Buka order KS-260922-8170.
3. Klik Kirim Form Brief -> Oke.
4. Jika gagal, modal akan tertutup dan kotak merah Error akan terlihat.
5. Kirim screenshot kotak merah tersebut.

Tidak mengubah SQL, Supabase, pembayaran, atau admin-kirim-brief.php.
