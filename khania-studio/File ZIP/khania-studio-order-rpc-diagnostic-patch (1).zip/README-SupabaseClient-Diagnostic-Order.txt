KHANIA STUDIO — DIAGNOSTIC ORDER RPC

Tujuan:
Patch sementara ini hanya menambahkan pencatatan response asli dari
Supabase/PostgREST ketika create_public_order() gagal.

Yang TIDAK diubah:
- database Supabase
- function create_public_order()
- tabel/RLS
- proses pembayaran
- alur order lainnya

Yang dicatat ke PHP error_log:
- HTTP status Supabase
- response body
- raw response
- cURL error

Tidak mencatat API key atau password.

CARA PAKAI:
1. Backup file hosting saat ini:
   lib/SupabaseClient.php
2. Upload file:
   SupabaseClient-diagnostic-order.php
   ke folder lib/
3. Rename file tersebut menjadi:
   SupabaseClient.php
4. Pastikan file berada di:
   /public_html/lib/SupabaseClient.php
5. Lakukan SATU kali test order dari website.
6. Jangan melakukan test berulang.
7. Buka error_log hosting dan cari baris:
   KHANIA ORDER RPC DIAGNOSTIC:
8. Kirim baris diagnostic tersebut kepada ChatGPT.

PENTING:
- Jangan kirim file .env.
- Jangan kirim service_role key atau password.
- Setelah error asli ditemukan, patch diagnostic ini akan kita ganti
  dengan perbaikan permanen.
