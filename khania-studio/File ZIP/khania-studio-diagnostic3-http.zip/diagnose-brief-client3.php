<?php
/**
 * KHANIA STUDIO — Client Brief Diagnostic 3
 * TEMPORARY. Delete after testing.
 *
 * This diagnostic inspects the actual HTTP status/body produced by
 * SupabaseClient::request() without exposing any API key.
 */

header('Content-Type: text/plain; charset=utf-8');

$orderNumber = trim((string)($_GET['order'] ?? 'KS-260922-85CA'));
$root = __DIR__;

echo "=== KHANIA STUDIO — CLIENT BRIEF DIAGNOSTIC 3 ===\n\n";
echo "PHP Version:              " . PHP_VERSION . "\n";
echo "Order under test:        " . $orderNumber . "\n";
echo "SupabaseClient exists:    " . (is_file($root . '/lib/SupabaseClient.php') ? 'YES' : 'NO') . "\n";
echo ".env exists:              " . (is_file($root . '/.env') ? 'YES' : 'NO') . "\n\n";

require_once $root . '/lib/SupabaseClient.php';

if (!class_exists('KhaniaStudio\\SupabaseClient')) {
    echo "ERROR: SupabaseClient class not found.\n";
    exit;
}

try {
    $client = new \KhaniaStudio\SupabaseClient();

    $ref = new ReflectionClass($client);
    $method = $ref->getMethod('request');
    $method->setAccessible(true);

    $params = [
        'select' => 'id,order_number,client_id,package_id,status,order_date',
        'order_number=eq' => $orderNumber,
        'limit' => 1,
    ];

    echo "=== TEST 1: ACTUAL SupabaseClient::request() ===\n";
    echo "Table:                    orders\n";
    echo "Method:                   GET\n";
    echo "Filter:                   order_number=eq.[hidden-value]\n";
    echo "Limit:                    1\n\n";

    $res = $method->invoke($client, 'GET', 'orders', $params);

    echo "HTTP Status:              " . ($res['status'] ?? '[missing]') . "\n";
    echo "Body type:                " . gettype($res['body'] ?? null) . "\n";

    echo "\n--- BODY (safe diagnostic output) ---\n";
    $body = $res['body'] ?? null;

    if (is_array($body)) {
        echo json_encode($body, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        echo "\n";
        echo "Top-level array count:    " . count($body) . "\n";

        if (isset($body[0]) && is_array($body[0])) {
            echo "Looks like row array:      YES\n";
            echo "First row keys:            " . implode(', ', array_keys($body[0])) . "\n";
        } else {
            echo "Looks like row array:      NO\n";
            echo "This may be a Supabase/PostgREST error object.\n";
        }
    } else {
        echo (string)$body . "\n";
    }

    echo "\n=== TEST 2: DIRECT cURL WITH SAME QUERY ===\n";

    $env = [];
    foreach (['SUPABASE_URL','SUPABASE_SERVICE_ROLE_KEY','SUPABASE_ANON_KEY'] as $k) {
        $env[$k] = (string)getenv($k);
    }

    $apiKey = $env['SUPABASE_SERVICE_ROLE_KEY'] !== ''
        ? $env['SUPABASE_SERVICE_ROLE_KEY']
        : $env['SUPABASE_ANON_KEY'];

    $url = rtrim($env['SUPABASE_URL'], '/')
        . '/rest/v1/orders?'
        . http_build_query($params, '', '&', PHP_QUERY_RFC3986);

    echo "HTTP URL query built:     " . preg_replace('/order_number=[^&]+/', 'order_number=[REDACTED]', $url) . "\n";

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST => 'GET',
        CURLOPT_HTTPHEADER => [
            'apikey: ' . $apiKey,
            'Authorization: Bearer ' . $apiKey,
            'Accept: application/json',
        ],
        CURLOPT_TIMEOUT => 30,
        CURLOPT_CONNECTTIMEOUT => 10,
    ]);

    $response = curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    $errno = curl_errno($ch);
    curl_close($ch);

    echo "HTTP Status:              " . $status . "\n";
    echo "cURL Error:               " . ($errno ? $error : 'NONE') . "\n";
    echo "--- DIRECT BODY ---\n";

    $decoded = json_decode($response, true);
    if (is_array($decoded)) {
        echo json_encode($decoded, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    } else {
        echo $response;
    }
    echo "\n";

    echo "\n=== CONCLUSION GUIDE ===\n";
    echo "1. If Test 1 HTTP Status is 4xx/5xx and body has code/message -> SupabaseClient is hiding an API error.\n";
    echo "2. If Test 2 is also 4xx/5xx -> query/auth/permission issue is confirmed.\n";
    echo "3. If Test 1 is 200 but body is not row-shaped -> inspect response handling.\n";
    echo "4. If Test 2 is 200 and returns the correct order -> SupabaseClient query construction/handling is the likely issue.\n";

} catch (Throwable $e) {
    echo "\n=== PHP EXCEPTION / ERROR ===\n";
    echo "Class:                    " . get_class($e) . "\n";
    echo "Message:                  " . $e->getMessage() . "\n";
    echo "File:                     " . $e->getFile() . "\n";
    echo "Line:                     " . $e->getLine() . "\n";
}

echo "\nDELETE THIS DIAGNOSTIC FILE AFTER TESTING.\n";
?>
