KHANIA STUDIO — STAGE 2E-1B PATCH
Admin Pesanan — Fix object/array website_briefs

TUJUAN
Memperbaiki status Form Brief di Admin Pesanan.

HASIL DIAGNOSTIK
Query Admin Pesanan berhasil membaca website_briefs untuk order KS-260922-85CA,
namun Supabase mengembalikan relasi website_briefs sebagai OBJECT (one-to-one),
bukan ARRAY. JavaScript lama mengambil (o.website_briefs||[])[0], sehingga hasilnya
undefined dan label jatuh ke "Belum Dikirim".

PERBAIKAN
1. Menambahkan getBrief(o) yang menerima OBJECT maupun ARRAY.
2. briefLabel() sekarang menggunakan getBrief(o).
3. Untuk status SUBMITTED, label menjadi "Brief Diterima".
4. Untuk status DRAFT:
   - brief_sent_at terisi -> "Form Brief Dikirim"
   - belum dikirim -> "Belum Dikirim"
5. sendBrief() juga menggunakan getBrief(o), sehingga resend detection tetap benar.
6. Tidak ada perubahan SQL, Supabase, API PHP, HTML, atau alur order/payment.

FILE YANG DIUPLOAD
Upload HANYA:
  admin-pesanan-live.js
ke:
  /public_html/js/admin-pesanan-live.js

SETELAH UPLOAD
1. Login Admin.
2. Buka Admin Pesanan.
3. Hard refresh browser (Ctrl+F5).
4. Cari order KS-260922-85CA.
5. Status Form Brief seharusnya: "Brief Diterima".
6. Tombol tindakan seharusnya bukan lagi "Kirim Brief" sebagai tindakan utama untuk brief yang sudah SUBMITTED.

CATATAN
Jika browser masih menampilkan versi lama, tambahkan query cache-buster pada URL
halaman Admin Pesanan, misalnya ?v=stage2e1b, atau lakukan Ctrl+F5.
